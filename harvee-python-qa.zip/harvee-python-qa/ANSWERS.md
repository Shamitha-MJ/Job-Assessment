# Harvee Technologies QA Assessment — Written Answers (Python + Playwright)

> Review and personalize these responses against the exact assessment prompt before submitting. If the employer provided a specific AI-generated code sample or incident scenario, use that original material rather than assuming the examples below match it.

## B1 — Reviewing AI-generated cart-total test code

When reviewing a cart-total test, I would check for these risks:

1. **Hardcoded URL:** use `base_url` configuration so the test can run against another environment without editing test code.
2. **Hardcoded credentials:** load configurable values from environment variables and keep `.env` out of version control.
3. **Fragile selectors:** prefer stable attributes such as `data-test` over selecting buttons by index.
4. **Fixed sleeps:** avoid `time.sleep()`; use Playwright locator assertions that wait for the expected state.
5. **Weak assertions:** verify exact text and numeric values, not just that an element exists.
6. **Subtotal not checked:** compare the sum of visible line-item prices with the displayed subtotal.
7. **Tax and total not reconciled:** assert that subtotal plus tax equals the total, rounded to two decimal places.
8. **No completion assertion:** after finishing checkout, verify the confirmation header and completion URL.
9. **Shared mutable state:** each test should set up its own cart and not depend on another test's execution order.
10. **Poor diagnostics:** retain useful failure output, screenshots or traces where supported, and clear test names.

A robust test should use independent setup, explicit assertions, stable selectors, and deterministic test data. I would first compare these points with the exact sample code supplied in the assessment before making line-specific comments.

## B2 — Automation approach

I use pytest as the test runner and Playwright's Python API for browser interaction. The Page Object Model keeps selectors and repeated page actions in `pages/`, while test scenarios and assertions stay in `tests/`. Configuration is provided through environment variables, and tests are designed to run independently.

## B3 — Defect reporting

A useful defect report includes a concise title, environment/build, preconditions, reproducible steps, expected result, actual result, severity/priority, and supporting evidence. I would record only defects I personally reproduced. I would not invent a production incident or claim an unverified issue occurred.

## Test coverage strategy

I prioritize high-impact customer flows: login, product sorting, cart changes, checkout validation, total calculations, and order confirmation. Negative and boundary cases are included alongside the happy path. Manual testing remains useful for exploratory behavior, accessibility judgment, and checks that are not appropriate to automate.

## What I would improve next

- Add tests for logout/session behavior and browser back navigation.
- Add cross-browser runs after confirming the supported browser matrix.
- Add accessibility checks and API coverage if the application and assessment permit them.
- Publish test reports as CI artifacts and separate environment failures from genuine product defects.
