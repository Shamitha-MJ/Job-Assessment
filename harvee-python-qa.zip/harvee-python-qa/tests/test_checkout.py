import re
from playwright.sync_api import expect
from pages.login_page import LoginPage
from pages.inventory_page import InventoryPage
from pages.checkout_page import CheckoutPage

def test_checkout_happy_path_and_order_confirmation(open_site, standard_credentials):
    page = open_site
    LoginPage(page).login(*standard_credentials)
    inventory = InventoryPage(page)
    inventory.add_product("sauce-labs-backpack")
    inventory.add_product("sauce-labs-bike-light")
    inventory.open_cart()
    page.get_by_test_id("checkout").click()
    checkout = CheckoutPage(page)
    checkout.fill_customer_details("Test", "Candidate", "600001")
    checkout.continue_checkout()
    expect(page.locator(".title")).to_have_text("Checkout: Overview")
    prices = [float(value.replace("$", "")) for value in page.locator(".inventory_item_price").all_text_contents()]
    subtotal = float(page.locator(".summary_subtotal_label").inner_text().split("$")[-1])
    tax = float(page.locator(".summary_tax_label").inner_text().split("$")[-1])
    total = float(page.locator(".summary_total_label").inner_text().split("$")[-1])
    assert round(sum(prices), 2) == round(subtotal, 2)
    assert round(subtotal + tax, 2) == round(total, 2)
    page.get_by_test_id("finish").click()
    expect(page.locator(".complete-header")).to_have_text("Thank you for your order!")
    expect(page).to_have_url(re.compile(r"checkout-complete\.html$"))

def test_checkout_requires_first_name(open_site, standard_credentials):
    page = open_site
    LoginPage(page).login(*standard_credentials)
    inventory = InventoryPage(page)
    inventory.add_product("sauce-labs-backpack")
    inventory.open_cart()
    page.get_by_test_id("checkout").click()
    page.get_by_test_id("lastName").fill("Candidate")
    page.get_by_test_id("postalCode").fill("600001")
    page.get_by_test_id("continue").click()
    expect(page.locator('[data-test="error"]')).to_contain_text("First Name is required")
