import re
from playwright.sync_api import expect
from pages.login_page import LoginPage
from pages.inventory_page import InventoryPage

def sign_in(page, credentials):
    LoginPage(page).login(*credentials)
    expect(page).to_have_url(re.compile(r"inventory\.html$"))

def test_default_product_sort_is_name_ascending(open_site, standard_credentials):
    page = open_site
    sign_in(page, standard_credentials)
    inventory = InventoryPage(page)
    names = inventory.product_names()
    assert names == sorted(names, key=str.casefold)

def test_sort_prices_low_to_high(open_site, standard_credentials):
    page = open_site
    sign_in(page, standard_credentials)
    inventory = InventoryPage(page)
    inventory.sort_dropdown.select_option("lohi")
    prices = inventory.prices()
    assert prices == sorted(prices)

def test_sort_prices_high_to_low(open_site, standard_credentials):
    page = open_site
    sign_in(page, standard_credentials)
    inventory = InventoryPage(page)
    inventory.sort_dropdown.select_option("hilo")
    prices = inventory.prices()
    assert prices == sorted(prices, reverse=True)

def test_adding_two_products_updates_cart_badge(open_site, standard_credentials):
    page = open_site
    sign_in(page, standard_credentials)
    inventory = InventoryPage(page)
    inventory.add_product("sauce-labs-backpack")
    inventory.add_product("sauce-labs-bike-light")
    expect(inventory.cart_badge).to_have_text("2")

def test_remove_product_updates_cart_badge(open_site, standard_credentials):
    page = open_site
    sign_in(page, standard_credentials)
    inventory = InventoryPage(page)
    inventory.add_product("sauce-labs-backpack")
    inventory.add_product("sauce-labs-bike-light")
    inventory.remove_product("sauce-labs-backpack")
    expect(inventory.cart_badge).to_have_text("1")
    inventory.open_cart()
    expect(page.locator(".cart_item")).to_have_count(1)
    expect(page.locator(".inventory_item_name")).to_have_text("Sauce Labs Bike Light")
