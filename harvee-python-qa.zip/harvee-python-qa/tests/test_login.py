import os
import re
from playwright.sync_api import expect
from pages.login_page import LoginPage

LOCKED_OUT_ERROR = "Epic sadface: Sorry, this user has been locked out."
INVALID_ERROR = "Epic sadface: Username and password do not match any user in this service"
EMPTY_USERNAME_ERROR = "Epic sadface: Username is required"
EMPTY_PASSWORD_ERROR = "Epic sadface: Password is required"

def test_standard_user_can_log_in(open_site, standard_credentials):
    page = open_site
    login = LoginPage(page)
    username, password = standard_credentials
    login.login(username, password)
    expect(page).to_have_url(re.compile(r"inventory\.html$"))
    expect(page.locator(".title")).to_have_text("Products")

def test_locked_out_user_sees_error(open_site):
    login = LoginPage(open_site)
    login.login(os.getenv("LOCKED_OUT_USERNAME", "locked_out_user"), os.getenv("STANDARD_PASSWORD", "secret_sauce"))
    assert login.error_text() == LOCKED_OUT_ERROR
    expect(open_site).to_have_url(re.compile(r"https://www\.saucedemo\.com/?$"))

def test_invalid_credentials_show_error(open_site):
    login = LoginPage(open_site)
    login.login(os.getenv("INVALID_USERNAME", "invalid_user_xyz"), os.getenv("INVALID_PASSWORD", "wrong_password"))
    assert login.error_text() == INVALID_ERROR

def test_empty_login_shows_username_required(open_site):
    login = LoginPage(open_site)
    login.submit_empty()
    assert login.error_text() == EMPTY_USERNAME_ERROR

def test_username_without_password_shows_password_required(open_site):
    login = LoginPage(open_site)
    login.username.fill(os.getenv("STANDARD_USERNAME", "standard_user"))
    login.login_button.click()
    assert login.error_text() == EMPTY_PASSWORD_ERROR
