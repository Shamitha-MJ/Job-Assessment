# Harvee Technologies QA Automation Assessment — Python + Playwright

A Python-based UI automation project for the SauceDemo demo shopping application. This repository uses **pytest + Playwright for Python**, Page Object Model (POM), environment-based configuration, and GitHub Actions.

## Application under test
- URL: https://www.saucedemo.com
- Scope: login validation, inventory sorting, cart operations, checkout totals, and order confirmation.
- Note: these tests require the public demo site and an internet connection. Test results may change if the demo site is unavailable.

## Requirements
- Python 3.10+
- pip
- Internet connection for installing dependencies and accessing SauceDemo

## Setup (Windows PowerShell)
```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
playwright install chromium
Copy-Item .env.example .env
```
If PowerShell blocks activation, you can run the tests using `.venv\Scripts\python.exe -m pytest` without activating the environment.

## Run tests
```powershell
pytest
```
Run a single suite:
```powershell
pytest tests/test_login.py
pytest tests/test_inventory_cart.py
pytest tests/test_checkout.py
```
Run with a visible browser:
```powershell
pytest --headed
```
Run with Playwright's browser tracing on failures:
```powershell
pytest --tracing retain-on-failure
```

## Credentials and configuration
The `.env.example` file lists configuration names and safe demo defaults. Copy it to `.env` for local overrides. Never commit `.env` or real credentials. The public SauceDemo demo credentials are used only for this assessment.

## Repository layout
```text
.
├── .github/workflows/python-playwright.yml
├── docs/
│   ├── app-observations.md
│   └── assessment-notes.md
├── pages/
│   ├── login_page.py
│   ├── inventory_page.py
│   └── checkout_page.py
├── tests/
│   ├── test_login.py
│   ├── test_inventory_cart.py
│   └── test_checkout.py
├── .env.example
├── .gitignore
├── ANSWERS.md
├── AI_USAGE.md
├── INTERVIEW_NOTES.md
├── manual-test-cases.md
├── conftest.py
├── pytest.ini
└── requirements.txt
```

## Automated coverage
The suite includes 12 scenarios:
1. Standard user login
2. Locked-out user error
3. Invalid credentials error
4. Empty login validation
5. Username-only validation
6. Default product name sorting
7. Price low-to-high sorting
8. Price high-to-low sorting
9. Add two products and verify cart badge
10. Remove a product and verify cart contents
11. Complete checkout and reconcile subtotal, tax, and total
12. Checkout validation when first name is missing

## Test design notes
- Page objects keep selectors and reusable actions separate from test assertions.
- Tests assert exact messages and values instead of checking only that an element exists.
- Playwright's locator assertions wait for expected UI state; no arbitrary sleeps are used.
- Test data and base URL can be configured through environment variables.
- Checkout math is checked using displayed line-item prices, subtotal, tax, and total.

## Known limitations
- SauceDemo is an external demo service; tests can fail due to network or service availability.
- These are UI-level checks and do not replace API, database, accessibility, or security testing.
- Review the selectors and expected messages against the live application before submission.
- Written answers and manual test cases should be reviewed and personalized so you can explain them confidently in an interview.

## Assessment documents
- `manual-test-cases.md`: manual test scenarios and expected outcomes.
- `ANSWERS.md`: written assessment responses.
- `AI_USAGE.md`: transparent record of AI assistance and verification.
- `INTERVIEW_NOTES.md`: concise explanations of the framework and test design.
