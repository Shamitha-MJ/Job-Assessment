import os
import pytest
from dotenv import load_dotenv
from playwright.sync_api import Page

load_dotenv()

@pytest.fixture(scope="session")
def base_url() -> str:
    return os.getenv("BASE_URL", "https://www.saucedemo.com").rstrip("/")

@pytest.fixture
def open_site(page: Page, base_url: str) -> Page:
    page.goto(base_url)
    return page

@pytest.fixture
def standard_credentials() -> tuple[str, str]:
    return (
        os.getenv("STANDARD_USERNAME", "standard_user"),
        os.getenv("STANDARD_PASSWORD", "secret_sauce"),
    )
