"""Page object for the SauceDemo login page."""
from playwright.sync_api import Page, expect

class LoginPage:
    def __init__(self, page: Page):
        self.page = page
        self.username = page.get_by_test_id("username")
        self.password = page.get_by_test_id("password")
        self.login_button = page.get_by_test_id("login-button")
        self.error = page.locator('[data-test="error"]')

    def open(self) -> None:
        self.page.goto("/")

    def login(self, username: str, password: str) -> None:
        self.username.fill(username)
        self.password.fill(password)
        self.login_button.click()

    def submit_empty(self) -> None:
        self.login_button.click()

    def error_text(self) -> str:
        expect(self.error).to_be_visible()
        return self.error.inner_text().strip()
