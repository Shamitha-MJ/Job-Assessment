"""Page object for checkout steps."""
from playwright.sync_api import Page

class CheckoutPage:
    def __init__(self, page: Page):
        self.page = page

    def fill_customer_details(self, first_name: str, last_name: str, postal_code: str) -> None:
        self.page.get_by_test_id("firstName").fill(first_name)
        self.page.get_by_test_id("lastName").fill(last_name)
        self.page.get_by_test_id("postalCode").fill(postal_code)

    def continue_checkout(self) -> None:
        self.page.get_by_test_id("continue").click()
