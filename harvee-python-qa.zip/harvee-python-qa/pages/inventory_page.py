"""Page object for the SauceDemo inventory and shopping cart."""
from playwright.sync_api import Page, expect

class InventoryPage:
    def __init__(self, page: Page):
        self.page = page
        self.title = page.locator(".title")
        self.cart_badge = page.locator(".shopping_cart_badge")
        self.cart_link = page.locator(".shopping_cart_link")
        self.sort_dropdown = page.get_by_test_id("product-sort-container")

    def add_product(self, product_test_id: str) -> None:
        self.page.get_by_test_id(f"add-to-cart-{product_test_id}").click()

    def remove_product(self, product_test_id: str) -> None:
        self.page.get_by_test_id(f"remove-{product_test_id}").click()

    def product_names(self) -> list[str]:
        return self.page.locator(".inventory_item_name").all_text_contents()

    def prices(self) -> list[float]:
        values = self.page.locator(".inventory_item_price").all_text_contents()
        return [float(value.replace("$", "")) for value in values]

    def open_cart(self) -> None:
        self.cart_link.click()
