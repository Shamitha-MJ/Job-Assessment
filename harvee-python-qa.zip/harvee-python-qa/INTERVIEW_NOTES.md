# Interview notes — Python + Playwright

## Why Playwright?
Playwright provides reliable browser automation, auto-waiting locators, multiple browser support, and useful debugging tools such as traces and screenshots.

## Why pytest?
pytest gives a simple test runner, fixtures, markers, and readable assertions for Python projects.

## Why Page Object Model?
Page objects centralize selectors and reusable actions. When a locator changes, it can often be updated in one place rather than in many tests.

## Why avoid fixed sleeps?
Fixed sleeps make tests slower and flaky. Playwright locator assertions wait for the expected UI state.

## How is checkout total tested?
The test sums displayed item prices, compares the sum with the subtotal, and checks that subtotal plus tax equals the displayed total to two decimal places.

## Limitations
These are UI tests against a public demo site. They do not validate backend persistence, production security, API behavior, or real payment processing.
