# Manual Test Cases — SauceDemo

**Environment:** https://www.saucedemo.com  
**Priority:** P1 = high, P2 = medium  
**Note:** Execute each case and record actual result/status before submitting. Expected outcomes below are test expectations, not claims of completed execution.

| ID | Area | Scenario | Steps | Expected result | Priority |
|---|---|---|---|---|---|
| TC01 | Login | Standard user login | Enter `standard_user` and `secret_sauce`; click Login | Products page opens | P1 |
| TC02 | Login | Locked-out user | Enter `locked_out_user` and `secret_sauce`; click Login | Locked-out error is shown | P1 |
| TC03 | Login | Invalid credentials | Enter invalid username/password; click Login | Invalid-credentials error is shown | P1 |
| TC04 | Login | Empty form | Click Login without entering values | Username-required error is shown | P1 |
| TC05 | Login | Username only | Enter username, leave password blank, click Login | Password-required error is shown | P2 |
| TC06 | Login | Password only | Enter password, leave username blank, click Login | Username-required error is shown | P2 |
| TC07 | Login | Logout | Log in and use the menu to log out | Login page is displayed | P1 |
| TC08 | Inventory | Default sorting | Log in and inspect product names | Names are ordered A–Z by default | P2 |
| TC09 | Inventory | Sort A–Z | Choose Name (A to Z) | Product names are ascending | P2 |
| TC10 | Inventory | Sort Z–A | Choose Name (Z to A) | Product names are descending | P2 |
| TC11 | Inventory | Sort price low-high | Choose Price (low to high) | Prices are ascending | P1 |
| TC12 | Inventory | Sort price high-low | Choose Price (high to low) | Prices are descending | P1 |
| TC13 | Cart | Add one product | Add Backpack | Cart badge shows 1 | P1 |
| TC14 | Cart | Add two products | Add Backpack and Bike Light | Cart badge shows 2 | P1 |
| TC15 | Cart | Remove product on inventory | Add Backpack, then remove it | Badge clears and button returns to Add to cart | P2 |
| TC16 | Cart | Remove product in cart | Add two products, open cart, remove one | Only the remaining product is listed | P1 |
| TC17 | Cart | Continue shopping | Open cart and click Continue Shopping | Inventory page opens | P2 |
| TC18 | Cart | Verify item details | Add a product and open cart | Product name, description, and price match inventory | P2 |
| TC19 | Checkout | Checkout navigation | Add item, open cart, click Checkout | Checkout information form opens | P1 |
| TC20 | Checkout | Missing first name | Leave first name blank and continue | Required-field error is shown | P1 |
| TC21 | Checkout | Missing last name | Leave last name blank and continue | Required-field error is shown | P1 |
| TC22 | Checkout | Missing postal code | Leave postal code blank and continue | Required-field error is shown | P1 |
| TC23 | Checkout | Cancel checkout info | Open checkout form and click Cancel | Returns to cart | P2 |
| TC24 | Checkout | Verify totals | Add two items and reach overview | Subtotal equals sum of item prices; total equals subtotal plus tax | P1 |
| TC25 | Checkout | Complete order | Complete all checkout steps and click Finish | Confirmation message is shown | P1 |

## Execution record

Fill this section after running the tests manually.

| Date | Tester | Environment | Passed | Failed | Blocked | Notes |
|---|---|---|---:|---:|---:|---|
| To be completed | To be completed | SauceDemo | — | — | — | Do not mark results until executed |
