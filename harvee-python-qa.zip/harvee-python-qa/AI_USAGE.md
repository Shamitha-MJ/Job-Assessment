# AI assistance and verification disclosure

AI assistance was used to help organize the project structure, draft test scenarios, and review Python/Playwright examples. The candidate should personally review every file, run the tests, confirm results, and edit any written answer to reflect their own understanding and work.

Before submission:
- Verify each test against the live application.
- Do not report tests as passed unless you ran them and observed a passing result.
- Replace generic or hypothetical examples with genuine observations.
- Be prepared to explain why each locator and assertion is used.
