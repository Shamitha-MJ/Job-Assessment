# Assessment notes

## Scope
Test the SauceDemo user journey from authentication through cart management and checkout completion.

## Risks
- External demo site availability and behavior can change.
- UI selector changes can break automation.
- A test account may have behavior intentionally different from the standard user.
- Financial total calculations should be asserted independently rather than only checking that checkout completes.

## Prioritization
P1: successful login, login errors, cart updates, checkout totals, order completion.
P2: sorting variants, navigation behavior, boundary validation, session behavior.

## Exit criteria
- All required manual cases are documented.
- At least eight automated tests exist and have been run against the intended target.
- Failures are investigated rather than hidden.
- README setup instructions work on a clean machine.
- Candidate can explain assertions, page objects, test data, and known limitations.
