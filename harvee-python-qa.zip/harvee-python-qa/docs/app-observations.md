# Application observations — SauceDemo

These are expected observations for the public demo application and should be rechecked manually before final submission.

- Login page contains username and password inputs, a Login button, and an error banner for invalid submissions.
- `standard_user` with the public demo password `secret_sauce` is expected to reach the Products inventory page.
- `locked_out_user` is expected to receive a locked-out error.
- Inventory displays product names, prices, add/remove buttons, a sort selector, and a cart link.
- Sorting options include name ascending/descending and price ascending/descending.
- Cart supports removing products and navigating to checkout.
- Checkout collects first name, last name, and postal code; overview displays item subtotal, tax, and total; Finish completes the demo order.

Do not claim these observations were verified during the current run unless you actually run the tests and inspect the site.
