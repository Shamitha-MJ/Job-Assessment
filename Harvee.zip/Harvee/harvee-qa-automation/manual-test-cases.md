# manual-test-cases.md
# Sauce Demo – Manual Test Cases

---

## Test Strategy (under 150 words)

The Sauce Demo application is a pure front-end SPA; there is no public API and no access to source code, so **no API or unit tests are included in this assessment**. The strategy is:

- **UI automation (Playwright):** Cover the core happy paths and high-priority negative paths that are stable, repeatable, and time-consuming to run manually. Target: ~15 automated cases.
- **Manual-only testing:** Exploratory, usability, accessibility, and boundary cases where human judgment is required, or where automating would cost more than the risk warrants.
- **Regression:** Automated suite runs on every push via GitHub Actions, giving fast feedback without human effort.
- **Prioritization:** P1 = block release; P2 = high impact; P3 = low/cosmetic.
- **Out of scope:** API layer, unit tests, back-end performance.

---

## Product Owner Questions & Assumptions

| # | Question | Assumption Made |
|---|----------|-----------------|
| 1 | Is the ~8% tax rate intentional and fixed, or is it environment-dependent? | Tax is computed dynamically by the app; tests read it from the DOM rather than hard-coding a rate. |
| 2 | Should a locked-out user see a specific support contact or help link? | Currently no link is shown; a P3 usability test is included. |
| 3 | Is the "problem_user" intentionally broken (wrong images, non-functional sort) or is it a regression? | Treated as intentional "chaos" user; defects are noted in the exploratory charter rather than raised as bugs. |
| 4 | Is cart persistence across sessions (browser refresh) a supported feature? | No: the app does not use localStorage; cart is lost on refresh. Not tested in automation. |
| 5 | Is sorting stability guaranteed when two items share the same price? | No specification found; TC05/TC06 sort pairs (name+price) together to detect any swap. |

---

## 15-Minute Exploratory Charter

**Mission:** Observe the behavior of the `problem_user` account. Separate real defects (broken expected behavior) from intentional chaos (deliberate simulation of a buggy user).

**Session duration:** 15 minutes  
**Tester:** [Your name]  
**Date:** [Fill in]

### Observations
| Observation | Real Defect? | Notes |
|-------------|-------------|-------|
| Product images show wrong item | Intentional chaos | All `problem_user` images display dog pictures |
| Sort dropdown changes option but product order does not change | **Potential real defect** | Sort by Price (low-high) does not reorder – same as the known B3 defect |
| "Add to cart" buttons on some items do nothing | Intentional chaos | JS handler appears broken for specific items |
| Checkout last name field does not accept input | **Potential real defect** | Standard checkout would fail; requires PO clarification |
| Cart badge increments correctly even when add-to-cart fails | Inconsistency noted | Could mislead user about cart state |

### Findings vs. Intentional Behavior
The `problem_user` is documented as simulating a real user with browser/device issues. Image bugs and some button failures appear intentional. The sorting failure overlaps with the known B3 defect and may be reproduced for more users than intended.

---

## 25 Manual Test Cases

| ID | Area | Test Type | Title | Preconditions | Steps | Test Data | Expected Result | Priority | Automation Decision |
|----|------|-----------|-------|---------------|-------|-----------|-----------------|----------|---------------------|
| TC01 | Login | Positive | Standard user can log in | Browser open, app accessible | 1. Navigate to https://www.saucedemo.com <br>2. Enter username: standard_user <br>3. Enter password: secret_sauce <br>4. Click Login | username=standard_user, password=secret_sauce | Redirected to /inventory.html, "Products" header visible | P1 | **Automated** – Core happy path; must run on every commit |
| TC02 | Login | Negative | Locked-out user sees error | Browser open | 1. Navigate to app <br>2. Enter locked_out_user / secret_sauce <br>3. Click Login | locked_out_user / secret_sauce | Stay on login page. Error: "Epic sadface: Sorry, this user has been locked out." | P1 | **Automated** – Exact error message verification |
| TC03 | Login | Negative | Invalid credentials show error | Browser open | 1. Enter invalid_user_xyz / wrong_password <br>2. Click Login | invalid_user_xyz / wrong_password | Error: "Epic sadface: Username and password do not match any user in this service" | P1 | **Automated** – Different error from TC02; worth automating |
| TC04 | Login | Boundary | Empty form shows username-required error | Browser open | 1. Do not fill any field <br>2. Click Login | (empty) / (empty) | Error: "Epic sadface: Username is required" | P1 | **Automated** – Validates form first-error priority |
| TC04b | Login | Boundary | Username only shows password-required error | Browser open | 1. Fill username only <br>2. Click Login | standard_user / (empty) | Error: "Epic sadface: Password is required" | P2 | **Automated** – Second boundary case |
| TC05 | Sorting | Positive | Sort price low to high: full list correct | Logged in as standard_user | 1. Open sort dropdown <br>2. Select "Price (low to high)" <br>3. Read all displayed prices | N/A | All 6 products displayed in ascending price order: $7.99, $9.99, $15.99, $15.99, $29.99, $49.99 | P1 | **Automated** – Entire list verified, not just first/last |
| TC06 | Sorting | Positive | Sort price high to low: full list correct | Logged in as standard_user | 1. Open sort dropdown <br>2. Select "Price (high to low)" <br>3. Read all displayed prices | N/A | Products in descending order: $49.99, $29.99, $15.99, $15.99, $9.99, $7.99 | P1 | **Automated** |
| TC07 | Sorting | Positive | Default sort is Name A-Z | Logged in as standard_user | 1. Do not change sort option <br>2. Read product names | N/A | Names in A-Z alphabetical order | P2 | **Automated** |
| TC08 | Cart | Positive | Add two products, badge = 2 | Logged in as standard_user | 1. Click "Add to cart" on Backpack <br>2. Click "Add to cart" on Bike Light | N/A | Cart badge shows "2" | P1 | **Automated** |
| TC09 | Cart | Positive | Remove one, badge = 1 and correct item remains | Logged in; two items in cart | 1. Click Remove on Backpack <br>2. Go to cart page | N/A | Badge = "1"; only Bike Light in cart | P1 | **Automated** |
| TC10 | Cart | Positive | Cart page shows correct name and price | Logged in | 1. Add Bolt T-Shirt and Fleece Jacket <br>2. Navigate to cart | N/A | Both names and prices correct in cart | P2 | **Automated** |
| TC11 | Cart | Positive | Continue Shopping returns to inventory | Logged in; one item in cart | 1. Go to cart page <br>2. Click "Continue Shopping" | N/A | Lands on /inventory.html | P2 | **Automated** |
| TC12 | Checkout | Positive | Full happy-path checkout | Logged in; two items in cart | 1. Go to cart <br>2. Click Checkout <br>3. Fill form <br>4. Click Continue <br>5. Verify totals <br>6. Click Finish | firstName=John, lastName=Doe, postalCode=12345 | Subtotal = sum of prices; total = subtotal + tax; confirmation header "Thank you for your order!"; cart empty | P1 | **Automated** – Math verification + confirmation |
| TC13 | Checkout | Negative | Validation: missing first name | Logged in; one item in cart; on step one | 1. Leave first name blank <br>2. Fill last/postal <br>3. Click Continue | firstName=(empty), lastName=Doe, postalCode=12345 | Error: "Error: First Name is required" | P1 | **Automated** – Part of test.each |
| TC14 | Checkout | Negative | Validation: missing last name | Same as TC13 | 1. Fill first name <br>2. Leave last name blank <br>3. Fill postal <br>4. Click Continue | firstName=John, lastName=(empty), postalCode=12345 | Error: "Error: Last Name is required" | P1 | **Automated** – Part of test.each |
| TC15 | Checkout | Negative | Validation: missing postal code | Same as TC13 | 1. Fill first and last name <br>2. Leave postal blank <br>3. Click Continue | firstName=John, lastName=Doe, postalCode=(empty) | Error: "Error: Postal Code is required" | P1 | **Automated** – Part of test.each |
| TC16 | Checkout | Positive | Cancel on overview returns to inventory | Logged in; on step two | 1. Click Cancel on overview page | N/A | Lands on /inventory.html | P2 | **Automated** |
| TC17 | Checkout | Positive | Cancel on step one returns to cart | Logged in; on step one | 1. Click Cancel on step-one form | N/A | Lands on /cart.html | P2 | **Automated** |
| TC18 | Cart | Positive | Remove product from products page | Logged in; one item in cart | 1. Click Remove button on inventory page <br>2. Check badge and cart | N/A | Badge disappears; cart empty | P2 | **Automated** |
| TC19 | Login | Positive | Logout clears session | Logged in | 1. Open menu <br>2. Click Logout | N/A | Lands on login page; session cookie cleared | P1 | Manual – Verifying session clearance requires cookie inspection; TC22b covers the redirect behavior |
| TC20 | Sorting | Positive | Sort name Z to A | Logged in | 1. Select "Name (Z to A)" <br>2. Read names | N/A | Names in reverse alphabetical order | P2 | **Automated** |
| TC21 | Cart | Usability | Cart persists on back-navigation | Logged in; item in cart | 1. Add item <br>2. Go to product detail <br>3. Click browser Back | N/A | Badge still shows correct count | P3 | Manual – Navigation state hard to assert reliably |
| TC22 | Security | Security | Unauthenticated access to /inventory.html | Not logged in | 1. Navigate directly to /inventory.html | N/A | Redirected to /; error: "…You can only access '/inventory.html' when you are logged in." | P1 | **Automated** |
| TC23 | Security | Security | Unauthenticated access to /checkout-step-one.html | Not logged in | 1. Navigate to /checkout-step-one.html | N/A | Redirected to /; error message contains "You can only access" | P1 | **Automated** |
| TC24 | Usability | Exploratory | Problem user: observe visual/UX defects | Logged in as problem_user | Follow 15-min charter above | N/A | Observations documented; real defects separated from intentional chaos | P3 | Manual – Exploratory; no binary pass/fail |
| TC25 | Accessibility | Accessibility | Keyboard navigation on login form | Browser open | 1. Press Tab to move to username <br>2. Type username <br>3. Press Tab to password <br>4. Type password <br>5. Press Enter | N/A | Focus moves correctly; login succeeds with keyboard only | P3 | Manual – Requires human judgment on focus indicators |
