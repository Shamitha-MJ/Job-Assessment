// test-data/testData.js
// ------------------------------------------------------------------
// Single source of truth for all test data.
// Credentials come from environment variables so nothing is hardcoded.
// Product data was verified live against https://www.saucedemo.com/
// ------------------------------------------------------------------

require('dotenv').config();

// ── Credentials ────────────────────────────────────────────────────
const USERS = {
  standard: {
    username: process.env.STANDARD_USER     || 'standard_user',
    password: process.env.STANDARD_PASSWORD || 'secret_sauce',
  },
  lockedOut: {
    username: process.env.LOCKED_OUT_USER     || 'locked_out_user',
    password: process.env.LOCKED_OUT_PASSWORD || 'secret_sauce',
  },
  invalid: {
    username: 'invalid_user_xyz',
    password: 'wrong_password_123',
  },
};

// ── Exact error messages (copied from the live app) ──────────────
const ERROR_MESSAGES = {
  emptyUsername:   'Epic sadface: Username is required',
  emptyPassword:   'Epic sadface: Password is required',
  lockedOut:       'Epic sadface: Sorry, this user has been locked out.',
  invalidCreds:    'Epic sadface: Username and password do not match any user in this service',
  protectedPage:   "Epic sadface: You can only access '/inventory.html' when you are logged in.",

  // Checkout form validation
  missingFirstName:  'Error: First Name is required',
  missingLastName:   'Error: Last Name is required',
  missingPostalCode: 'Error: Postal Code is required',
};

// ── Products (verified from the live inventory page) ─────────────
// Each entry has: name, price (number), addButtonId, removeButtonId
const PRODUCTS = {
  backpack: {
    name:           'Sauce Labs Backpack',
    price:          29.99,
    addTestId:      'add-to-cart-sauce-labs-backpack',
    removeTestId:   'remove-sauce-labs-backpack',
  },
  bikeLight: {
    name:           'Sauce Labs Bike Light',
    price:          9.99,
    addTestId:      'add-to-cart-sauce-labs-bike-light',
    removeTestId:   'remove-sauce-labs-bike-light',
  },
  boltTShirt: {
    name:           'Sauce Labs Bolt T-Shirt',
    price:          15.99,
    addTestId:      'add-to-cart-sauce-labs-bolt-t-shirt',
    removeTestId:   'remove-sauce-labs-bolt-t-shirt',
  },
  fleeceJacket: {
    name:           'Sauce Labs Fleece Jacket',
    price:          49.99,
    addTestId:      'add-to-cart-sauce-labs-fleece-jacket',
    removeTestId:   'remove-sauce-labs-fleece-jacket',
  },
  onesie: {
    name:           'Sauce Labs Onesie',
    price:          7.99,
    addTestId:      'add-to-cart-sauce-labs-onesie',
    removeTestId:   'remove-sauce-labs-onesie',
  },
  redTShirt: {
    name:           'Test.allTheThings() T-Shirt (Red)',
    price:          15.99,
    addTestId:      'add-to-cart-test.allthethings()-t-shirt-(red)',
    removeTestId:   'remove-test.allthethings()-t-shirt-(red)',
  },
};

// ── Checkout customer data ────────────────────────────────────────
const CHECKOUT = {
  valid: {
    firstName:  'John',
    lastName:   'Doe',
    postalCode: '12345',
  },
};

// ── Checkout validation test cases (used with test.each) ─────────
const CHECKOUT_VALIDATION_CASES = [
  {
    label:       'missing first name',
    firstName:   '',
    lastName:    'Doe',
    postalCode:  '12345',
    expectedMsg: ERROR_MESSAGES.missingFirstName,
  },
  {
    label:       'missing last name',
    firstName:   'John',
    lastName:    '',
    postalCode:  '12345',
    expectedMsg: ERROR_MESSAGES.missingLastName,
  },
  {
    label:       'missing postal code',
    firstName:   'John',
    lastName:    'Doe',
    postalCode:  '',
    expectedMsg: ERROR_MESSAGES.missingPostalCode,
  },
];

// ── Confirmation page text ────────────────────────────────────────
const CONFIRMATION = {
  header:  'Thank you for your order!',
  subText: 'Your order has been dispatched, and will arrive just as fast as the pony can get there!',
};

// ── Sort option values (the <option value="..."> attributes) ─────
const SORT_OPTIONS = {
  nameAZ:   'az',
  nameZA:   'za',
  priceLH:  'lohi',
  priceHL:  'hilo',
};

module.exports = {
  USERS,
  ERROR_MESSAGES,
  PRODUCTS,
  CHECKOUT,
  CHECKOUT_VALIDATION_CASES,
  CONFIRMATION,
  SORT_OPTIONS,
};
