// pages/CartPage.js
// ------------------------------------------------------------------
// Represents the Sauce Demo shopping cart page.
// URL: https://www.saucedemo.com/cart.html
// ------------------------------------------------------------------

class CartPage {
  /**
   * @param {import('@playwright/test').Page} page
   */
  constructor(page) {
    this.page = page;

    // ── Locators ───────────────────────────────────────────────
    this.continueShoppingButton = page.getByTestId('continue-shopping');
    this.checkoutButton         = page.getByTestId('checkout');

    // All product names inside the cart
    this.cartItemNames          = page.locator('.cart_item .inventory_item_name');

    // All product prices inside the cart
    this.cartItemPrices         = page.locator('.cart_item .inventory_item_price');

    // All cart item rows (each row is one product)
    this.cartItems              = page.locator('.cart_item');
  }

  // ── Navigation ─────────────────────────────────────────────────

  /** Navigate directly to the cart page. */
  async goto() {
    await this.page.goto('/cart.html');
  }

  // ── Actions ────────────────────────────────────────────────────

  /** Click "Continue Shopping" to go back to the products page. */
  async continueShopping() {
    await this.continueShoppingButton.click();
  }

  /** Click "Checkout" to go to checkout step one. */
  async proceedToCheckout() {
    await this.checkoutButton.click();
  }

  /**
   * Remove a product from the cart using its data-test remove button.
   * The remove button in the cart follows the same naming pattern as
   * the one on the inventory page.
   * @param {string} removeTestId  e.g. 'remove-sauce-labs-backpack'
   */
  async removeProduct(removeTestId) {
    await this.page.getByTestId(removeTestId).click();
  }

  // ── Getters / Queries ──────────────────────────────────────────

  /**
   * Returns names of all products currently in the cart.
   * @returns {Promise<string[]>}
   */
  async getCartItemNames() {
    return this.cartItemNames.allTextContents();
  }

  /**
   * Returns the number of products in the cart (count of rows).
   * @returns {Promise<number>}
   */
  async getCartItemCount() {
    return this.cartItems.count();
  }

  /**
   * Returns prices of all cart items as numbers (no $ symbol).
   * @returns {Promise<number[]>}
   */
  async getCartItemPrices() {
    const rawTexts = await this.cartItemPrices.allTextContents();
    return rawTexts.map((t) => parseFloat(t.replace('$', '')));
  }
}

module.exports = { CartPage };
