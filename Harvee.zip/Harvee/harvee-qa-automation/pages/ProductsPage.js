// pages/ProductsPage.js
// ------------------------------------------------------------------
// Represents the Sauce Demo inventory / products page.
// URL: https://www.saucedemo.com/inventory.html
//
// Locators and interactions live here.
// Tests call methods; they never touch raw selectors.
// ------------------------------------------------------------------

class ProductsPage {
  /**
   * @param {import('@playwright/test').Page} page
   */
  constructor(page) {
    this.page = page;

    // ── Locators ───────────────────────────────────────────────
    // Sort dropdown (select element)
    this.sortDropdown     = page.getByTestId('product-sort-container');

    // Shopping cart icon / badge
    this.cartLink         = page.getByTestId('shopping-cart-link');
    this.cartBadge        = page.getByTestId('shopping-cart-badge');

    // Burger / side-nav menu
    this.menuButton       = page.locator('#react-burger-menu-btn');
    this.logoutLink       = page.getByTestId('logout-sidebar-link');

    // All product names on the page (returned as a Locator list)
    this.productNames     = page.locator('.inventory_item_name');

    // All product prices on the page
    this.productPrices    = page.locator('.inventory_item_price');
  }

  // ── Navigation ─────────────────────────────────────────────────

  /** Navigate directly to the inventory page (requires login first). */
  async goto() {
    await this.page.goto('/inventory.html');
  }

  // ── Actions ────────────────────────────────────────────────────

  /**
   * Add a product to the cart using its data-test add button.
   * @param {string} addTestId  e.g. 'add-to-cart-sauce-labs-backpack'
   */
  async addProductToCart(addTestId) {
    await this.page.getByTestId(addTestId).click();
  }

  /**
   * Remove a product from the cart using its data-test remove button.
   * @param {string} removeTestId  e.g. 'remove-sauce-labs-backpack'
   */
  async removeProduct(removeTestId) {
    await this.page.getByTestId(removeTestId).click();
  }

  /**
   * Choose a sort order from the dropdown.
   * @param {string} value  e.g. 'lohi', 'hilo', 'az', 'za'
   */
  async sortProducts(value) {
    await this.sortDropdown.selectOption(value);
  }

  /** Click the shopping cart icon to navigate to the cart page. */
  async goToCart() {
    await this.cartLink.click();
  }

  /** Open the side navigation and click Logout. */
  async logout() {
    await this.menuButton.click();
    await this.logoutLink.click();
  }

  // ── Getters / Queries ──────────────────────────────────────────

  /**
   * Returns the number shown on the cart badge.
   * Throws if no badge is visible (cart is empty).
   * @returns {Promise<string>}
   */
  async getCartBadgeCount() {
    return this.cartBadge.textContent();
  }

  /**
   * Collect all product names currently displayed on the page.
   * @returns {Promise<string[]>}
   */
  async getAllProductNames() {
    return this.productNames.allTextContents();
  }

  /**
   * Collect all displayed prices and parse them to numbers.
   * The DOM shows "$29.99"; we strip the "$" and parse to float.
   * @returns {Promise<number[]>}
   */
  async getAllProductPrices() {
    const rawTexts = await this.productPrices.allTextContents();
    return rawTexts.map((t) => parseFloat(t.replace('$', '')));
  }
}

module.exports = { ProductsPage };
