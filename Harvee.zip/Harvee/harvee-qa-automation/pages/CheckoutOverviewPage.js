// pages/CheckoutOverviewPage.js
// ------------------------------------------------------------------
// Represents Checkout Step Two – the order overview/summary page.
// URL: https://www.saucedemo.com/checkout-step-two.html
//
// Important: Tax rate is NOT assumed.  We read subtotal and total
// from the DOM, then compute tax = total - subtotal.  This makes
// the test resilient to tax-rate changes.
// ------------------------------------------------------------------

class CheckoutOverviewPage {
  /**
   * @param {import('@playwright/test').Page} page
   */
  constructor(page) {
    this.page = page;

    // ── Locators ───────────────────────────────────────────────
    // Price summary labels (confirmed selectors from live app)
    this.subtotalLabel = page.locator('.summary_subtotal_label');
    this.taxLabel      = page.locator('.summary_tax_label');
    this.totalLabel    = page.locator('.summary_total_label');

    // Buttons
    this.finishButton  = page.getByTestId('finish');
    this.cancelButton  = page.getByTestId('cancel');

    // Product rows in the overview
    this.cartItemNames = page.locator('.cart_item .inventory_item_name');
  }

  // ── Actions ────────────────────────────────────────────────────

  /** Click Finish to complete the order. */
  async finish() {
    await this.finishButton.click();
  }

  /** Click Cancel to go back to the inventory page. */
  async cancel() {
    await this.cancelButton.click();
  }

  // ── Getters ────────────────────────────────────────────────────

  /**
   * Parse a currency label like "Item total: $29.99" → 29.99
   * @param {import('@playwright/test').Locator} locator
   * @returns {Promise<number>}
   */
  async _parseCurrencyLabel(locator) {
    const text = await locator.textContent();
    // Find the first number with optional decimal in the string
    const match = text.match(/[\d]+\.[\d]{2}/);
    if (!match) throw new Error(`Could not parse currency from: "${text}"`);
    return parseFloat(match[0]);
  }

  /**
   * Returns the item subtotal as a number (no $ symbol).
   * DOM shows: "Item total: $X.XX"
   * @returns {Promise<number>}
   */
  async getSubtotal() {
    return this._parseCurrencyLabel(this.subtotalLabel);
  }

  /**
   * Returns the tax as a number.
   * DOM shows: "Tax: $X.XX"
   * @returns {Promise<number>}
   */
  async getTax() {
    return this._parseCurrencyLabel(this.taxLabel);
  }

  /**
   * Returns the grand total as a number.
   * DOM shows: "Total: $X.XX"
   * @returns {Promise<number>}
   */
  async getTotal() {
    return this._parseCurrencyLabel(this.totalLabel);
  }

  /**
   * Returns the full subtotal label text as-is (for snapshot assertions).
   * @returns {Promise<string>}
   */
  async getSubtotalText() {
    return this.subtotalLabel.textContent();
  }

  /**
   * Returns names of all products shown in the overview.
   * @returns {Promise<string[]>}
   */
  async getCartItemNames() {
    return this.cartItemNames.allTextContents();
  }
}

module.exports = { CheckoutOverviewPage };
