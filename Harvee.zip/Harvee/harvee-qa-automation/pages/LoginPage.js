// pages/LoginPage.js
// ------------------------------------------------------------------
// Represents the Sauce Demo login screen.
// URL: https://www.saucedemo.com/
//
// RULE: All selectors live here.  Tests must NEVER contain raw
// locators – they call methods like login() or getErrorMessage().
// ------------------------------------------------------------------

class LoginPage {
  /**
   * @param {import('@playwright/test').Page} page - Playwright page object
   */
  constructor(page) {
    this.page = page;

    // ── Locators (all use data-test attribute via getByTestId) ──
    // getByTestId() looks for: [data-test="..."]
    this.usernameInput   = page.getByTestId('username');
    this.passwordInput   = page.getByTestId('password');
    this.loginButton     = page.getByTestId('login-button');

    // Error message container (no data-test; class selector is reliable)
    this.errorMessage    = page.locator('[data-test="error"]');
  }

  // ── Actions ────────────────────────────────────────────────────

  /**
   * Navigate to the login page.
   * Uses baseURL from playwright.config.js so no URL is hardcoded here.
   */
  async goto() {
    await this.page.goto('/');
  }

  /**
   * Fill in the login form and click the Login button.
   * @param {string} username
   * @param {string} password
   */
  async login(username, password) {
    await this.usernameInput.fill(username);
    await this.passwordInput.fill(password);
    await this.loginButton.click();
  }

  /**
   * Submit the form without filling anything (tests empty-field validation).
   */
  async submitEmpty() {
    await this.loginButton.click();
  }

  /**
   * Submit with only the username filled (tests missing-password validation).
   * @param {string} username
   */
  async submitWithUsernameOnly(username) {
    await this.usernameInput.fill(username);
    await this.loginButton.click();
  }

  // ── Assertions / Getters ────────────────────────────────────────

  /**
   * Returns the text of the error banner.
   * Playwright auto-waits until the element is visible.
   * @returns {Promise<string>}
   */
  async getErrorMessage() {
    return this.errorMessage.textContent();
  }
}

module.exports = { LoginPage };
