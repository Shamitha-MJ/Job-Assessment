// pages/CheckoutPage.js
// ------------------------------------------------------------------
// Represents Checkout Step One – the customer information form.
// URL: https://www.saucedemo.com/checkout-step-one.html
// ------------------------------------------------------------------

class CheckoutPage {
  /**
   * @param {import('@playwright/test').Page} page
   */
  constructor(page) {
    this.page = page;

    // ── Locators ───────────────────────────────────────────────
    // Form fields (data-test values confirmed from live app)
    this.firstNameInput  = page.getByTestId('firstName');
    this.lastNameInput   = page.getByTestId('lastName');
    this.postalCodeInput = page.getByTestId('postalCode');

    // Buttons
    this.continueButton  = page.getByTestId('continue');
    this.cancelButton    = page.getByTestId('cancel');

    // Validation error message
    this.errorMessage    = page.locator('[data-test="error"]');
  }

  // ── Actions ────────────────────────────────────────────────────

  /**
   * Fill the checkout form and click Continue.
   * Pass empty strings to test validation errors.
   *
   * @param {string} firstName
   * @param {string} lastName
   * @param {string} postalCode
   */
  async fillForm(firstName, lastName, postalCode) {
    // Only fill if a value is provided; empty strings test validation.
    if (firstName) await this.firstNameInput.fill(firstName);
    if (lastName)  await this.lastNameInput.fill(lastName);
    if (postalCode) await this.postalCodeInput.fill(postalCode);
    await this.continueButton.click();
  }

  /**
   * A convenience wrapper to complete the checkout form with all valid data.
   * This is what you call in a happy-path test.
   *
   * @param {{ firstName: string, lastName: string, postalCode: string }} customer
   */
  async completeCheckout(customer) {
    await this.fillForm(customer.firstName, customer.lastName, customer.postalCode);
  }

  /** Click Cancel to go back to the cart page. */
  async cancel() {
    await this.cancelButton.click();
  }

  // ── Getters ────────────────────────────────────────────────────

  /**
   * Returns the text of the validation error banner.
   * @returns {Promise<string>}
   */
  async getErrorMessage() {
    return this.errorMessage.textContent();
  }
}

module.exports = { CheckoutPage };
