// pages/ConfirmationPage.js
// ------------------------------------------------------------------
// Represents the order confirmation page (checkout complete).
// URL: https://www.saucedemo.com/checkout-complete.html
// ------------------------------------------------------------------

class ConfirmationPage {
  /**
   * @param {import('@playwright/test').Page} page
   */
  constructor(page) {
    this.page = page;

    // ── Locators ───────────────────────────────────────────────
    // Confirmed from live app inspection
    this.headerText     = page.locator('.complete-header');
    this.subText        = page.locator('.complete-text');
    this.backHomeButton = page.getByTestId('back-to-products');
  }

  // ── Getters ────────────────────────────────────────────────────

  /**
   * Returns the large confirmation heading text.
   * Expected: "Thank you for your order!"
   * @returns {Promise<string>}
   */
  async getHeaderText() {
    return this.headerText.textContent();
  }

  /**
   * Returns the smaller paragraph text below the heading.
   * @returns {Promise<string>}
   */
  async getSubText() {
    return this.subText.textContent();
  }

  // ── Actions ────────────────────────────────────────────────────

  /** Click "Back Home" to return to the products page. */
  async goBackHome() {
    await this.backHomeButton.click();
  }
}

module.exports = { ConfirmationPage };
