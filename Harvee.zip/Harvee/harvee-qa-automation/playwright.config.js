// playwright.config.js
// ------------------------------------------------------------------
// This file configures Playwright Test.
// All values come from environment variables (loaded from .env via
// dotenv).  Defaults are provided so tests work out of the box even
// without a .env file.
// ------------------------------------------------------------------

// Load the .env file so process.env is populated BEFORE we read it.
require('dotenv').config();

const { defineConfig, devices } = require('@playwright/test');

module.exports = defineConfig({
  // ------- Test discovery -------
  testDir: './tests',           // where Playwright looks for *.spec.js
  testMatch: '**/*.spec.js',

  // ------- Timeouts -------
  timeout: 30_000,              // 30 s per test step
  expect: { timeout: 10_000 }, // 10 s for web-first assertions

  // ------- Retries -------
  // 0 locally so failures are obvious; 1 in CI to absorb transient blips.
  retries: process.env.CI ? 1 : 0,

  // ------- Parallelism -------
  workers: process.env.CI ? 2 : 1,
  fullyParallel: false, // keep sequential for predictable local runs

  // ------- Base URL -------
  // Override via BASE_URL in .env.  Default points at the real site.
  use: {
    baseURL: process.env.BASE_URL || 'https://www.saucedemo.com',

    // Attribute Playwright uses for getByTestId()
    testIdAttribute: 'data-test',

    // Capture a screenshot + trace when a test fails.
    screenshot: 'only-on-failure',
    trace: 'on-first-retry',

    // Run headless by default; set HEADLESS=false in .env to watch.
    headless: process.env.HEADLESS !== 'false',
  },

  // ------- Reporters -------
  reporter: [
    ['list'],                                       // live console output
    ['html', { outputFolder: 'playwright-report', open: 'never' }],
    ['junit', { outputFile: 'test-results/results.xml' }],
  ],

  // ------- Output folder for failures -------
  outputDir: 'test-results/artifacts',

  // ------- Browsers -------
  // In CI (GitHub Actions), only Chromium runs.
  //   - msedge is NOT available on ubuntu-latest via Playwright CDN.
  //   - webkit needs extra Linux deps not in the CI browser install step.
  // Locally, all three browsers are available if you install them:
  //   npx playwright install chromium webkit msedge
  projects: [
    // Chromium always runs (locally and in CI)
    {
      name: 'chromium',
      use: { ...devices['Desktop Chrome'] },
    },

    // WebKit and Edge only run locally (not in CI)
    ...(!process.env.CI
      ? [
          {
            name: 'webkit',
            use: { ...devices['Desktop Safari'] },
          },
          {
            name: 'edge',
            use: { ...devices['Desktop Edge'], channel: 'msedge' },
          },
        ]
      : []),
  ],
});
