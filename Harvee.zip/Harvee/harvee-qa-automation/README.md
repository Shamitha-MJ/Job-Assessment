# Harvee QA Automation – Playwright JavaScript Project

A complete, interview-ready Playwright (JavaScript) automation project for the **Sauce Demo** application, built as part of the Harvee Technologies QA Automation Engineer assessment.

---

## Overview

| Item | Value |
|------|-------|
| Application under test | https://www.saucedemo.com |
| Automation framework | Playwright Test (JavaScript / CommonJS) |
| Browsers | Chromium, WebKit, Microsoft Edge |
| Pattern | Page Object Model (POM) |
| Reporters | HTML report + JUnit XML + console list |
| CI | GitHub Actions |

---

## Technology Stack

- **[@playwright/test](https://playwright.dev/)** – Browser automation and test runner
- **[dotenv](https://github.com/motdotla/dotenv)** – Loads credentials from `.env` (no secrets in code)
- **Node.js 18+** – Runtime
- **CommonJS** (`require` / `module.exports`) – Simple, no transpilation needed

---

## Prerequisites

- Node.js 18 or later – [download here](https://nodejs.org/)
- npm 8 or later (comes with Node)
- Windows CMD, PowerShell, or Git Bash

---

## Installation

### 1. Install Node dependencies
```cmd
npm install
```

### 2. Set up environment variables
```cmd
copy .env.example .env
```
Open `.env` in Notepad and confirm the values. The defaults already point to the real Sauce Demo site with the known credentials.

### 3. Install Playwright browsers
```cmd
npx playwright install chromium
```

To also install WebKit and Edge (required for full cross-browser runs):
```cmd
npx playwright install chromium webkit msedge
```

---

## Running Tests (Windows CMD Commands)

### Run all tests (headless, all browsers)
```cmd
npx playwright test
```

### Run all tests in Chromium only
```cmd
npx playwright test --project=chromium
```

### Run a single test file
```cmd
npx playwright test tests/login.spec.js
```

### Run tests headed (you can watch the browser)
```cmd
npx playwright test --headed
```

### Run tests headless (default behavior)
```cmd
npx playwright test --headless
```

### Open the HTML report after a test run
```cmd
npx playwright show-report
```

The HTML report is saved at:
```
playwright-report\index.html
```

### Locate the JUnit XML report
```
test-results\results.xml
```

### Locate failure screenshots and traces
```
test-results\artifacts\
```
Screenshots are only captured on failure (configured in `playwright.config.js`).

---

## Project Structure

```
harvee-qa-automation/
├── pages/                        # Page Object classes
│   ├── LoginPage.js
│   ├── ProductsPage.js
│   ├── CartPage.js
│   ├── CheckoutPage.js
│   ├── CheckoutOverviewPage.js
│   └── ConfirmationPage.js
├── tests/                        # Test files
│   ├── login.spec.js             # TC01-TC04b
│   ├── sorting.spec.js           # TC05, TC06, TC07, TC20
│   ├── cart.spec.js              # TC08-TC11, TC18
│   ├── checkout.spec.js          # TC12-TC17
│   └── security.spec.js          # TC22, TC23
├── test-data/
│   └── testData.js               # All test data (credentials from .env)
├── docs/
│   └── app-observations.md       # Phase 2 live inspection findings
├── .github/workflows/
│   └── playwright.yml            # GitHub Actions CI pipeline
├── .env.example                  # Template for .env (commit this)
├── .env                          # Your actual credentials (NEVER commit)
├── .gitignore
├── package.json
├── playwright.config.js
├── README.md
├── ANSWERS.md
├── AI_USAGE.md
├── INTERVIEW_NOTES.md
└── manual-test-cases.md
```

---

## Manual-to-Automated Test Mapping

| ID | Area | Title | Status |
|----|------|-------|--------|
| TC01 | Login | Standard user login | ✅ Automated – `tests/login.spec.js` |
| TC02 | Login | Locked-out user error | ✅ Automated – `tests/login.spec.js` |
| TC03 | Login | Invalid credentials error | ✅ Automated – `tests/login.spec.js` |
| TC04 | Login | Empty form validation | ✅ Automated – `tests/login.spec.js` |
| TC04b | Login | Username only validation | ✅ Automated – `tests/login.spec.js` |
| TC05 | Sorting | Price low to high | ✅ Automated – `tests/sorting.spec.js` |
| TC06 | Sorting | Price high to low | ✅ Automated – `tests/sorting.spec.js` |
| TC07 | Sorting | Default A-Z | ✅ Automated – `tests/sorting.spec.js` |
| TC08 | Cart | Add two products, badge = 2 | ✅ Automated – `tests/cart.spec.js` |
| TC09 | Cart | Remove one, badge = 1 | ✅ Automated – `tests/cart.spec.js` |
| TC10 | Cart | Cart shows correct items | ✅ Automated – `tests/cart.spec.js` |
| TC11 | Cart | Continue Shopping navigation | ✅ Automated – `tests/cart.spec.js` |
| TC12 | Checkout | Full happy path + math | ✅ Automated – `tests/checkout.spec.js` |
| TC13 | Checkout | Validation: missing first name | ✅ Automated – `tests/checkout.spec.js` |
| TC14 | Checkout | Validation: missing last name | ✅ Automated – `tests/checkout.spec.js` |
| TC15 | Checkout | Validation: missing postal code | ✅ Automated – `tests/checkout.spec.js` |
| TC16 | Checkout | Cancel from overview | ✅ Automated – `tests/checkout.spec.js` |
| TC17 | Checkout | Cancel from step one | ✅ Automated – `tests/checkout.spec.js` |
| TC18 | Cart | Remove from products page | ✅ Automated – `tests/cart.spec.js` |
| TC19 | Login | Logout clears session | Manual only – session/cookie inspection |
| TC20 | Sorting | Name Z to A | ✅ Automated – `tests/sorting.spec.js` |
| TC21 | Cart | Cart persists on back-nav | Manual only – browser navigation state |
| TC22 | Security | Unauth access /inventory.html | ✅ Automated – `tests/security.spec.js` |
| TC22b | Security | Post-logout /inventory.html | ✅ Automated – `tests/security.spec.js` |
| TC23 | Security | Unauth access /checkout-step-one | ✅ Automated – `tests/security.spec.js` |
| TC24 | Usability | Exploratory: problem_user | Manual only – exploratory |
| TC25 | Accessibility | Keyboard navigation | Manual only – human judgment |

**Total automated: 20 scenarios across 5 test files.**

---

## Known Limitations

1. **Live network dependency** – Tests hit `saucedemo.com` directly. If the site is unreachable, all tests fail. For a production project, add a network stub or a canary test that warns instead.
2. **Edge browser** – Requires Edge to be installed locally. If missing, remove the `edge` project from `playwright.config.js` or run only `--project=chromium`.
3. **WebKit on Windows** – May require running `npx playwright install-deps webkit` if system libraries are missing.
4. **`[B1_AI_CODE]` and `[B3_DEFECT]`** – These placeholders in `ANSWERS.md` need your real input before final submission.
5. **C2 incident** – `INTERVIEW_NOTES.md` contains a HYPOTHETICAL incident. Replace with your own genuine experience.

---

## Scaling to 200 Tests

When the suite grows from 20 to 200 tests, these practices keep it maintainable:

**Page Objects:** Every new area of the app gets its own page class. Selector changes require one edit in one file, not 20 tests.

**Fixtures:** Create a Playwright fixture (`test.extend`) that handles login once per test, so every test starts with a fresh authenticated session without repeating 4 lines of login code.

**Tags and filters:** Prefix critical tests with `@smoke`, use `npx playwright test --grep "@smoke"` to run only the fast check-in suite (< 2 minutes).

**Test data:** Centralise all data in `testData.js`. For data-intensive suites, load from a JSON file or environment-specific CSV so the same tests run against different data sets.

**Parallel workers:** Set `workers: 4` in `playwright.config.js` (or `workers: '50%'` to use half the CPU cores). Each test is already independent so parallel runs are safe.

**CI:** GitHub Actions matrix can run Chromium, WebKit, and Edge in parallel jobs. Total pipeline time stays under 10 minutes even at 200 tests.

**Reporting:** The JUnit XML report feeds directly into GitHub Actions test summaries, Azure DevOps, or Allure for historical trend tracking.

---

## Author

Built for the Harvee Technologies QA Automation Engineer assessment.
