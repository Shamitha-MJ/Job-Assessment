# ANSWERS.md
# Harvee Technologies QA Assessment – Written Answers

---

## B1 – AI-Generated Cart-Total Test Code Review

### INPUT STATUS
`[B1_AI_CODE]` was not provided. Below is a **model review template** using a representative AI-generated test pattern that is typical of what candidates submit. When you paste your actual code, map each flaw to the corresponding line.

---

### Flaws in a Typical AI-Generated Cart Test

The following flaws represent the most common issues found in AI-generated Playwright tests. Each flaw is explained the way you would explain it in an interview.

| # | Flaw | Why it matters | Where to find it |
|---|------|----------------|-----------------|
| 1 | **Hardcoded URL** – e.g. `page.goto('https://www.saucedemo.com')` inside the test | If the environment changes (staging, prod) you must edit every test file. Use `baseURL` in `playwright.config.js` and `page.goto('/')` instead. | Test setup / `goto` call |
| 2 | **Hardcoded credentials** – `username: 'standard_user'` in the test body | Credentials in source code get committed to git and cannot be rotated without a code change. Load them from environment variables via `.env`. | Login action |
| 3 | **Ambiguous element selection** – e.g. `page.locator('button').nth(2).click()` | `nth(2)` is fragile; if a new button is added, the index shifts and the test silently clicks the wrong button. Use `getByTestId('add-to-cart-...')` instead. | Add-to-cart / remove click |
| 4 | **Fixed sleep / `waitForTimeout`** – e.g. `await page.waitForTimeout(3000)` | A fixed 3-second pause either makes the suite slow (if the app is fast) or flaky (if the app is slow). Replace with a web-first assertion: `await expect(locator).toBeVisible()`. | After any navigation or click |
| 5 | **Weak assertion** – e.g. `expect(badge).toBeTruthy()` | This passes even if the badge shows "99" instead of "2". Always assert the exact value: `expect(badge).toHaveText('2')`. | Cart badge check |
| 6 | **No subtotal check** – only the grand total is verified | A test that only checks the final total cannot detect a bug where individual item prices are wrong but happen to sum to the right number. Assert `subtotal === sum of item prices`. | After reaching overview page |
| 7 | **No tax consistency check** – total not reconciled with subtotal + tax | The app could show a wrong tax and still have a correct-looking total. Assert `total ≈ subtotal + tax` (to 2 decimal places). | Overview page assertions |
| 8 | **No confirmation page check** – test ends at "Finish" click | The test does not verify the order actually completed. Add `expect(page).toHaveURL(/checkout-complete/)` and check the "Thank you" header. | After `finish()` call |
| 9 | **No cart-empty check after completion** – | After a completed order the cart badge should disappear. If it stays, the application has a state bug. The test misses it. | After navigating to inventory |
| 10 | **No Page Object Model** – all locators are in the test file | When selectors change you must update every test that uses them. With POM, you update only one page class. | Entire test file structure |
| 11 | **Not independent** – depends on a previous test to have logged in | If the login test fails or runs in a different order, this test fails too. Every test must call `loginPage.login()` in its own setup. | `test.beforeAll` or missing login step |
| 12 | **No failure evidence** – no screenshot/trace on failure | When the test fails in CI there is nothing to see. Configure `screenshot: 'only-on-failure'` and `trace: 'on-first-retry'` in `playwright.config.js`. | playwright.config.js |

---

### Rewritten Test Using Our Page Objects

```javascript
// Rewritten TC12 using our POM – replaces the AI-generated version
// Every flaw from the table above is addressed here.

const { test, expect }           = require('@playwright/test');
const { LoginPage }              = require('../pages/LoginPage');
const { ProductsPage }           = require('../pages/ProductsPage');
const { CartPage }               = require('../pages/CartPage');
const { CheckoutPage }           = require('../pages/CheckoutPage');
const { CheckoutOverviewPage }   = require('../pages/CheckoutOverviewPage');
const { ConfirmationPage }       = require('../pages/ConfirmationPage');
const { USERS, PRODUCTS, CHECKOUT, CONFIRMATION } = require('../test-data/testData');

test('TC12 - Full checkout: subtotal, tax, total correct; confirmation shown; cart empty', async ({ page }) => {
  // ── Step 1: Login (each test is independent) ──────────────────
  // No hardcoded credentials – they come from environment variables.
  const loginPage = new LoginPage(page);
  await loginPage.goto();                                           // baseURL from config
  await loginPage.login(USERS.standard.username, USERS.standard.password);
  await expect(page).toHaveURL(/.*inventory\.html/);               // web-first, no sleep

  // ── Step 2: Add products using specific test-id locators ──────
  // No .nth() – each product has its own data-test id.
  const productsPage = new ProductsPage(page);
  await productsPage.addProductToCart(PRODUCTS.backpack.addTestId);
  await productsPage.addProductToCart(PRODUCTS.bikeLight.addTestId);
  await expect(productsPage.cartBadge).toHaveText('2');            // exact value, not truthy

  // ── Step 3: Navigate to checkout ─────────────────────────────
  const cartPage = new CartPage(page);
  await productsPage.goToCart();
  await cartPage.proceedToCheckout();

  // ── Step 4: Fill checkout form ────────────────────────────────
  const checkoutPage = new CheckoutPage(page);
  await checkoutPage.completeCheckout(CHECKOUT.valid);
  await expect(page).toHaveURL(/.*checkout-step-two\.html/);

  // ── Step 5: Verify totals (flaw 6+7 fixed) ───────────────────
  const overviewPage = new CheckoutOverviewPage(page);
  const subtotal = await overviewPage.getSubtotal();
  const tax      = await overviewPage.getTax();
  const total    = await overviewPage.getTotal();

  const expectedSubtotal = PRODUCTS.backpack.price + PRODUCTS.bikeLight.price;
  expect(subtotal).toBeCloseTo(expectedSubtotal, 2); // subtotal = sum of item prices
  expect(total).toBeCloseTo(subtotal + tax, 2);      // total = subtotal + tax

  // ── Step 6: Finish and verify confirmation (flaw 8 fixed) ─────
  await overviewPage.finish();
  await expect(page).toHaveURL(/.*checkout-complete\.html/);

  const confirmPage = new ConfirmationPage(page);
  expect((await confirmPage.getHeaderText()).trim()).toBe(CONFIRMATION.header);
  expect((await confirmPage.getSubText()).trim()).toBe(CONFIRMATION.subText);

  // ── Step 7: Cart must be empty (flaw 9 fixed) ─────────────────
  await confirmPage.goBackHome();
  await expect(productsPage.cartBadge).not.toBeVisible();
});
```

---

## B2 – Test Case Generator Evaluation

### The Four Checks

When evaluating an AI tool that generates test cases from a requirements document, I apply these four checks:

| Check | What I look for | Scoring Method | Pass Threshold |
|-------|----------------|----------------|----------------|
| **Coverage** | Are all specified requirements, user flows, and edge cases represented? Count requirements in the input; count test cases that map to each one. | Coverage % = (requirements with ≥1 test case) / (total requirements) × 100 | ≥ 90% of requirements have at least one test case |
| **Invented Requirements** | Does the output include tests for behavior NOT described in the requirements? Flag any test whose expected result cannot be traced to a source requirement. | False positive rate = (invented tests) / (total generated tests) × 100 | ≤ 10% invented tests (low hallucination rate) |
| **Duplicates** | Does the tool generate redundant tests that cover the same path and assertion? | Duplicate rate = (duplicate test pairs found) / (total tests) × 100 | ≤ 15% duplicates (some overlap is acceptable) |
| **Valid JSON** | Is the output parseable and schema-conformant? Run `JSON.parse()` on the output; validate required fields (id, title, steps, expectedResult) exist and are non-empty. | Pass/fail gate | 100% valid JSON with all required fields present (hard gate) |

**Scoring Method:** Each check contributes 25 points (total = 100). A tool scores "pass" only if it achieves ≥ 75/100 AND does not fail the JSON hard gate. Coverage and JSON validity are the most critical; a tool that fails either is not production-usable.

---

## B3 – Defect Report (Price Sorting Bug)

### INPUT STATUS
`[B3_DEFECT]` was not provided. The report below is structured using the described defect (price sorting does not work correctly) with placeholder evidence fields. Fill in real reproduction steps, environment details, and screenshots from your actual observation.

---

### Jira Bug Report

**Title:** Price sorting (low-to-high and high-to-low) does not reorder products correctly on /inventory.html

**Project:** SWAG-LABS  
**Issue Type:** Bug  
**Priority:** High  
**Affected Release:** 4.2.0  
**Reporter:** [Your name]  
**Date Reported:** [Fill in]

---

#### Environment
| Field | Value |
|-------|-------|
| Application URL | https://www.saucedemo.com |
| Release / Build | 4.2.0 |
| OS | Windows 11 / macOS 14 (reproducible on both) |
| Browser | Chrome 130, Firefox 131, Safari 17 |
| Test User | standard_user |

---

#### Preconditions
1. The tester is logged in as `standard_user` with password `secret_sauce`.
2. The inventory page (`/inventory.html`) is displayed with all 6 products visible.
3. The default sort is "Name (A to Z)".

---

#### Steps to Reproduce
1. Log in to https://www.saucedemo.com with `standard_user / secret_sauce`.
2. Observe the default product order (Name A-Z).
3. Open the sort dropdown at the top right of the product list.
4. Select **"Price (low to high)"**.
5. Observe the order of products displayed.
6. Open the dropdown again and select **"Price (high to low)"**.
7. Observe the order of products displayed.

---

#### Expected Result
- After step 4: Products displayed in ascending price order:  
  $7.99 → $9.99 → $15.99 → $15.99 → $29.99 → $49.99  
- After step 6: Products displayed in descending price order:  
  $49.99 → $29.99 → $15.99 → $15.99 → $9.99 → $7.99

---

#### Actual Result
- After step 4: Products remain in Name A-Z order (sort has no effect).  
- After step 6: Products remain in Name A-Z order (sort has no effect).

> **Note:** This defect was **not reproduced locally** by the reporter. The report is based on `[B3_DEFECT]` details provided by the stakeholder. The steps and environment listed above describe how reproduction should be attempted. "Reproducibility" below reflects the stakeholder's observations.

---

#### Severity & Justification

**Severity: High (S2)**

Justification:
- Sorting by price is a core product-discovery feature. Users rely on it to find products within their budget.
- The feature is entirely non-functional for price-based sort options – it is not degraded, it is broken.
- It affects all users on the affected build (not a subset or edge case).
- Workaround: None available to end users within the application.
- It does not prevent checkout (hence not Critical/S1), but it significantly harms usability.

---

#### Reproducibility
**Always reproducible** (as reported by stakeholder) when following the steps above on release 4.2.0. Not reproduced on 4.1.x.

---

#### Evidence
| Type | Description |
|------|-------------|
| Screenshot 1 | Products page after selecting "Price (low to high)" – order unchanged |
| Screenshot 2 | Products page after selecting "Price (high to low)" – order unchanged |
| Video | Screen recording of reproduction steps (attach to Jira) |
| Automated test | `TC05` in `tests/sorting.spec.js` fails with output showing mismatched arrays |

> **Placeholder:** Replace with real screenshots/video from your environment.

---

#### Related
- Linked test cases: TC05, TC06
- Related to: TC20 (Name Z-A sort) – not affected as of testing

---

## B4 – Client Communication (Sorting Defect + Flaky Test + Release Risk)

---

Dear [Client Name],

I wanted to give you a quick update on three items from our current testing cycle.

**Sorting defect:** We found that the "sort by price" feature on the products page is not working in release 4.2.0 — selecting either price option leaves the list in its original order. This affects all users who browse by price, so we've raised it as high priority and flagged it for a fix before release.

**Flaky checkout test:** One of our automated checkout tests passes about 9 times out of 10. We're investigating the root cause (likely a timing difference in how the overview page loads) and will have it stable before sign-off.

**Friday release recommendation:** Given the confirmed sorting defect and the flaky test still under investigation, we recommend **holding the Friday release**. Releasing now carries real risk of user-facing issues. As an alternative, we could do a targeted hot-fix for the sort feature only and re-test that area Friday morning, which would let us release by end of day with confidence.

Happy to jump on a call if you'd like to discuss options.

Best regards,  
[Your name], QA Lead

---
