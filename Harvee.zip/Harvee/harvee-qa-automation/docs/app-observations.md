# docs/app-observations.md
# Sauce Demo – Live App Inspection Findings
# Conducted during Phase 2 of the Harvee QA Assessment

---

## 1. Login Page (https://www.saucedemo.com/)

### Page Title
`Swag Labs`

### Input Locators (data-test attributes)
| Element | data-test value |
|---------|----------------|
| Username input | `username` |
| Password input | `password` |
| Login button | `login-button` |
| Error message container | `error` |

### Exact Error Messages (copied character-for-character from the DOM)

| Scenario | Exact Error Text |
|----------|-----------------|
| Empty username + empty password | `Epic sadface: Username is required` |
| Username filled, password empty | `Epic sadface: Password is required` |
| locked_out_user / secret_sauce | `Epic sadface: Sorry, this user has been locked out.` |
| invalid_user / wrong_password | `Epic sadface: Username and password do not match any user in this service` |
| Unauthenticated /inventory.html | `Epic sadface: You can only access '/inventory.html' when you are logged in.` |

---

## 2. Inventory Page (https://www.saucedemo.com/inventory.html)

### Page Header
`.title` text = `Products`

### Key Locators
| Element | Selector |
|---------|---------|
| Sort dropdown | `data-test="product-sort-container"` |
| Cart icon/link | `data-test="shopping-cart-link"` |
| Cart badge | `data-test="shopping-cart-badge"` |
| Burger menu button | `id="react-burger-menu-btn"` |
| Logout link | `data-test="logout-sidebar-link"` |
| Product name | `.inventory_item_name` |
| Product price | `.inventory_item_price` |

### Sort Dropdown Options
| Option Text | value attribute |
|-------------|----------------|
| Name (A to Z) | `az` |
| Name (Z to A) | `za` |
| Price (low to high) | `lohi` |
| Price (high to low) | `hilo` |

**Default selected option:** `az` (Name A to Z)

### All 6 Products (Default A-Z Order)

| # | Name | Price | Add Button data-test | Remove Button data-test |
|---|------|-------|----------------------|------------------------|
| 1 | Sauce Labs Backpack | $29.99 | `add-to-cart-sauce-labs-backpack` | `remove-sauce-labs-backpack` |
| 2 | Sauce Labs Bike Light | $9.99 | `add-to-cart-sauce-labs-bike-light` | `remove-sauce-labs-bike-light` |
| 3 | Sauce Labs Bolt T-Shirt | $15.99 | `add-to-cart-sauce-labs-bolt-t-shirt` | `remove-sauce-labs-bolt-t-shirt` |
| 4 | Sauce Labs Fleece Jacket | $49.99 | `add-to-cart-sauce-labs-fleece-jacket` | `remove-sauce-labs-fleece-jacket` |
| 5 | Sauce Labs Onesie | $7.99 | `add-to-cart-sauce-labs-onesie` | `remove-sauce-labs-onesie` |
| 6 | Test.allTheThings() T-Shirt (Red) | $15.99 | `add-to-cart-test.allthethings()-t-shirt-(red)` | `remove-test.allthethings()-t-shirt-(red)` |

### Prices Sorted Low-to-High
$7.99, $9.99, $15.99, $15.99, $29.99, $49.99

### Prices Sorted High-to-Low
$49.99, $29.99, $15.99, $15.99, $9.99, $7.99

---

## 3. Cart Page (https://www.saucedemo.com/cart.html)

### Key Locators
| Element | Selector |
|---------|---------|
| Cart item name | `.cart_item .inventory_item_name` |
| Cart item price | `.cart_item .inventory_item_price` |
| Cart item row | `.cart_item` |
| Continue Shopping button | `data-test="continue-shopping"` |
| Checkout button | `data-test="checkout"` |

---

## 4. Checkout Step One (https://www.saucedemo.com/checkout-step-one.html)

### Key Locators
| Element | data-test |
|---------|----------|
| First name input | `firstName` |
| Last name input | `lastName` |
| Postal code input | `postalCode` |
| Continue button | `continue` |
| Cancel button | `cancel` |
| Error message | `error` |

### Validation Error Messages (exact)
| Missing Field | Error Text |
|--------------|-----------|
| First name | `Error: First Name is required` |
| Last name | `Error: Last Name is required` |
| Postal code | `Error: Postal Code is required` |

---

## 5. Checkout Overview / Step Two (https://www.saucedemo.com/checkout-step-two.html)

### Key Locators
| Element | Selector |
|---------|---------|
| Subtotal label | `.summary_subtotal_label` |
| Tax label | `.summary_tax_label` |
| Total label | `.summary_total_label` |
| Finish button | `data-test="finish"` |
| Cancel button | `data-test="cancel"` |

### Currency Label Format (exact)
- Subtotal: `"Item total: $39.98"`
- Tax: `"Tax: $3.20"`
- Total: `"Total: $43.18"`

**Observed tax rate:** Approximately 8% (but NOT hardcoded in tests – computed from DOM values)

---

## 6. Confirmation Page (https://www.saucedemo.com/checkout-complete.html)

### Key Locators
| Element | Selector |
|---------|---------|
| Header | `.complete-header` |
| Sub-text | `.complete-text` |
| Back Home button | `data-test="back-to-products"` |

### Exact Text Values
- **Header:** `Thank you for your order!`
- **Sub-text:** `Your order has been dispatched, and will arrive just as fast as the pony can get there!`

---

## 7. Protected Route Behavior

**Test:** Navigate to `/inventory.html` without logging in (fresh browser, no session cookie).

**Result:** The app immediately redirects to `/` (the login page root).  
**Error shown:** `Epic sadface: You can only access '/inventory.html' when you are logged in.`

**Test:** Log in → log out → navigate to `/inventory.html`.  
**Result:** Same redirect and same error message.

---

## 8. Notes & Gotchas

1. The cart badge (`data-test="shopping-cart-badge"`) is **not present in the DOM** when the cart is empty. Use `not.toBeVisible()` not `toHaveText('0')`.
2. The "Add to cart" button text changes to "Remove" after clicking. The `data-test` attribute also changes. Both IDs are recorded in the product table above.
3. Two products share the price $15.99 (Bolt T-Shirt and Red T-Shirt). Sort tests must handle ties.
4. The `.inventory_item_name` inside the cart page is the same class as on inventory. Use the `.cart_item` parent to scope it to the cart.
5. The burger menu has an animation; Playwright's auto-waiting handles this, but the logout link must be clicked after the menu is visible.
