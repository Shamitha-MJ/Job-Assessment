// tests/cart.spec.js
// ------------------------------------------------------------------
// Cart test suite – covers TC08, TC09, TC10, TC11, TC18.
// ------------------------------------------------------------------

const { test, expect } = require('@playwright/test');
const { LoginPage }    = require('../pages/LoginPage');
const { ProductsPage } = require('../pages/ProductsPage');
const { CartPage }     = require('../pages/CartPage');
const { USERS, PRODUCTS } = require('../test-data/testData');

test.describe('Shopping Cart', () => {

  // Shared login helper
  async function loginAsStandardUser(page) {
    const loginPage = new LoginPage(page);
    await loginPage.goto();
    await loginPage.login(USERS.standard.username, USERS.standard.password);
    await expect(page).toHaveURL(/.*inventory\.html/);
  }

  // ──────────────────────────────────────────────────────────────
  // TC08 – Add two products; cart badge must show 2
  // ──────────────────────────────────────────────────────────────
  test('TC08 - Add two products to cart, badge count equals 2', async ({ page }) => {
    await loginAsStandardUser(page);
    const productsPage = new ProductsPage(page);

    // Add product 1 (Backpack)
    await productsPage.addProductToCart(PRODUCTS.backpack.addTestId);

    // Add product 2 (Bike Light)
    await productsPage.addProductToCart(PRODUCTS.bikeLight.addTestId);

    // Badge must now show '2'
    await expect(productsPage.cartBadge).toHaveText('2');
  });

  // ──────────────────────────────────────────────────────────────
  // TC09 – Add two products, remove one; badge = 1 and cart has
  //        exactly the remaining product
  // ──────────────────────────────────────────────────────────────
  test('TC09 - Remove one product from cart, badge count becomes 1 and correct item remains', async ({ page }) => {
    await loginAsStandardUser(page);
    const productsPage = new ProductsPage(page);
    const cartPage     = new CartPage(page);

    // Add both
    await productsPage.addProductToCart(PRODUCTS.backpack.addTestId);
    await productsPage.addProductToCart(PRODUCTS.bikeLight.addTestId);
    await expect(productsPage.cartBadge).toHaveText('2');

    // Remove Backpack
    await productsPage.removeProduct(PRODUCTS.backpack.removeTestId);

    // Badge should now show '1'
    await expect(productsPage.cartBadge).toHaveText('1');

    // Navigate to cart and verify only Bike Light is there
    await productsPage.goToCart();
    const names = await cartPage.getCartItemNames();

    // Exactly one item
    expect(names).toHaveLength(1);

    // And it must be the Bike Light, not the Backpack
    expect(names[0]).toBe(PRODUCTS.bikeLight.name);
  });

  // ──────────────────────────────────────────────────────────────
  // TC10 – Cart page shows the correct product name and price
  // ──────────────────────────────────────────────────────────────
  test('TC10 - Cart page displays correct product names and prices', async ({ page }) => {
    await loginAsStandardUser(page);
    const productsPage = new ProductsPage(page);
    const cartPage     = new CartPage(page);

    // Add Bolt T-Shirt and Fleece Jacket
    await productsPage.addProductToCart(PRODUCTS.boltTShirt.addTestId);
    await productsPage.addProductToCart(PRODUCTS.fleeceJacket.addTestId);

    await productsPage.goToCart();

    const names  = await cartPage.getCartItemNames();
    const prices = await cartPage.getCartItemPrices();

    // Both products must appear (order may vary, so sort before compare)
    expect(names.sort()).toEqual(
      [PRODUCTS.boltTShirt.name, PRODUCTS.fleeceJacket.name].sort()
    );

    // Prices must match known values
    expect(prices.sort((a, b) => a - b)).toEqual(
      [PRODUCTS.boltTShirt.price, PRODUCTS.fleeceJacket.price].sort((a, b) => a - b)
    );
  });

  // ──────────────────────────────────────────────────────────────
  // TC11 – "Continue Shopping" from cart returns to inventory
  // ──────────────────────────────────────────────────────────────
  test('TC11 - Continue Shopping button returns to products page', async ({ page }) => {
    await loginAsStandardUser(page);
    const productsPage = new ProductsPage(page);
    const cartPage     = new CartPage(page);

    await productsPage.addProductToCart(PRODUCTS.backpack.addTestId);
    await productsPage.goToCart();

    // Must be on cart URL
    await expect(page).toHaveURL(/.*cart\.html/);

    // Click continue shopping
    await cartPage.continueShopping();

    // Must return to inventory
    await expect(page).toHaveURL(/.*inventory\.html/);
  });

  // ──────────────────────────────────────────────────────────────
  // TC18 – Remove a product using the Remove button on the
  //        products page; badge disappears
  // ──────────────────────────────────────────────────────────────
  test('TC18 - Removing product from products page removes it from cart', async ({ page }) => {
    await loginAsStandardUser(page);
    const productsPage = new ProductsPage(page);
    const cartPage     = new CartPage(page);

    // Add Onesie
    await productsPage.addProductToCart(PRODUCTS.onesie.addTestId);
    await expect(productsPage.cartBadge).toHaveText('1');

    // Remove it using the Remove button that replaces "Add to cart"
    await productsPage.removeProduct(PRODUCTS.onesie.removeTestId);

    // Badge must disappear entirely (no items in cart)
    await expect(productsPage.cartBadge).not.toBeVisible();

    // Cart page should be empty
    await productsPage.goToCart();
    const count = await cartPage.getCartItemCount();
    expect(count).toBe(0);
  });

});
