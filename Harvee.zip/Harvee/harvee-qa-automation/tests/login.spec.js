// tests/login.spec.js
// ------------------------------------------------------------------
// Login test suite – covers TC01 through TC04.
//
// Every test is independent: it starts fresh, sets up its own state,
// and does not rely on any other test having run first.
// ------------------------------------------------------------------

const { test, expect } = require('@playwright/test');
const { LoginPage }    = require('../pages/LoginPage');
const { USERS, ERROR_MESSAGES } = require('../test-data/testData');

test.describe('Login', () => {

  // ──────────────────────────────────────────────────────────────
  // TC01 – Positive: standard user can log in
  // ──────────────────────────────────────────────────────────────
  test('TC01 - Standard user can log in successfully', async ({ page }) => {
    const loginPage = new LoginPage(page);

    // Step 1: Open the login page
    await loginPage.goto();

    // Step 2: Enter valid credentials and click Login
    await loginPage.login(USERS.standard.username, USERS.standard.password);

    // Step 3: Assert the browser navigated to the inventory page
    // toHaveURL is a web-first assertion – Playwright waits automatically.
    await expect(page).toHaveURL(/.*inventory\.html/);

    // Step 4: Assert the page title is visible (proves we really landed there)
    await expect(page.locator('.title')).toHaveText('Products');
  });

  // ──────────────────────────────────────────────────────────────
  // TC02 – Negative: locked-out user sees the correct error
  // ──────────────────────────────────────────────────────────────
  test('TC02 - Locked-out user sees correct error message', async ({ page }) => {
    const loginPage = new LoginPage(page);

    await loginPage.goto();
    await loginPage.login(USERS.lockedOut.username, USERS.lockedOut.password);

    // User must NOT be redirected to inventory
    await expect(page).toHaveURL('/');

    // The exact error message must appear
    const message = await loginPage.getErrorMessage();
    expect(message.trim()).toBe(ERROR_MESSAGES.lockedOut);
  });

  // ──────────────────────────────────────────────────────────────
  // TC03 – Negative: wrong credentials show the right error
  // ──────────────────────────────────────────────────────────────
  test('TC03 - Invalid credentials show error message', async ({ page }) => {
    const loginPage = new LoginPage(page);

    await loginPage.goto();
    await loginPage.login(USERS.invalid.username, USERS.invalid.password);

    await expect(page).toHaveURL('/');

    const message = await loginPage.getErrorMessage();
    expect(message.trim()).toBe(ERROR_MESSAGES.invalidCreds);
  });

  // ──────────────────────────────────────────────────────────────
  // TC04 – Boundary / Negative: empty form shows username-required error
  // Submitting with neither field filled → username error fires first.
  // ──────────────────────────────────────────────────────────────
  test('TC04 - Empty form submission shows username required error', async ({ page }) => {
    const loginPage = new LoginPage(page);

    await loginPage.goto();
    await loginPage.submitEmpty(); // click Login without filling anything

    await expect(page).toHaveURL('/');

    const message = await loginPage.getErrorMessage();
    expect(message.trim()).toBe(ERROR_MESSAGES.emptyUsername);
  });

  // ──────────────────────────────────────────────────────────────
  // Additional: username filled but no password → password-required error
  // ──────────────────────────────────────────────────────────────
  test('TC04b - Username only shows password required error', async ({ page }) => {
    const loginPage = new LoginPage(page);

    await loginPage.goto();
    await loginPage.submitWithUsernameOnly(USERS.standard.username);

    await expect(page).toHaveURL('/');

    const message = await loginPage.getErrorMessage();
    expect(message.trim()).toBe(ERROR_MESSAGES.emptyPassword);
  });

});
