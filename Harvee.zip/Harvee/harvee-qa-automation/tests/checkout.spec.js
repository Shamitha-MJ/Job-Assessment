// tests/checkout.spec.js
// ------------------------------------------------------------------
// Checkout test suite – covers TC12-TC16.
//
// TC12: Full happy path with math verification (subtotal + tax = total).
// TC13-TC15: Parameterized validation using test.each.
// TC16: Cancel from overview returns to inventory.
// ------------------------------------------------------------------

const { test, expect }           = require('@playwright/test');
const { LoginPage }              = require('../pages/LoginPage');
const { ProductsPage }           = require('../pages/ProductsPage');
const { CartPage }               = require('../pages/CartPage');
const { CheckoutPage }           = require('../pages/CheckoutPage');
const { CheckoutOverviewPage }   = require('../pages/CheckoutOverviewPage');
const { ConfirmationPage }       = require('../pages/ConfirmationPage');
const {
  USERS,
  PRODUCTS,
  CHECKOUT,
  CHECKOUT_VALIDATION_CASES,
  CONFIRMATION,
} = require('../test-data/testData');

// Helper: login, add given products, navigate to checkout step one.
async function setupCheckout(page, productKeys) {
  const loginPage    = new LoginPage(page);
  const productsPage = new ProductsPage(page);
  const cartPage     = new CartPage(page);

  await loginPage.goto();
  await loginPage.login(USERS.standard.username, USERS.standard.password);
  await expect(page).toHaveURL(/.*inventory\.html/);

  for (const key of productKeys) {
    await productsPage.addProductToCart(PRODUCTS[key].addTestId);
  }

  await productsPage.goToCart();
  await cartPage.proceedToCheckout();
  await expect(page).toHaveURL(/.*checkout-step-one\.html/);
}

test.describe('Checkout', () => {

  // ──────────────────────────────────────────────────────────────
  // TC12 – Full happy-path checkout
  // Verifies: subtotal = sum of item prices; total = subtotal + tax;
  // confirmation message; cart is empty after completion.
  // ──────────────────────────────────────────────────────────────
  test('TC12 - Full checkout: subtotal, tax, total correct; confirmation shown; cart empty', async ({ page }) => {
    // Use two products so the sum is non-trivial
    await setupCheckout(page, ['backpack', 'bikeLight']);

    const checkoutPage    = new CheckoutPage(page);
    const overviewPage    = new CheckoutOverviewPage(page);
    const confirmPage     = new ConfirmationPage(page);
    const productsPage    = new ProductsPage(page);

    // ── Step 1: Fill the info form ────────────────────────────
    await checkoutPage.completeCheckout(CHECKOUT.valid);
    await expect(page).toHaveURL(/.*checkout-step-two\.html/);

    // ── Step 2: Read the displayed numbers ───────────────────
    const subtotal = await overviewPage.getSubtotal();
    const tax      = await overviewPage.getTax();
    const total    = await overviewPage.getTotal();

    // Expected subtotal from our known product prices
    const expectedSubtotal =
      PRODUCTS.backpack.price + PRODUCTS.bikeLight.price;

    // Subtotal must equal the sum of item prices (2-decimal precision)
    expect(subtotal).toBeCloseTo(expectedSubtotal, 2);

    // Tax is displayed; we don't assume its rate.
    // But: total must equal subtotal + tax (DOM consistency check).
    expect(total).toBeCloseTo(subtotal + tax, 2);

    // ── Step 3: Finish order ──────────────────────────────────
    await overviewPage.finish();
    await expect(page).toHaveURL(/.*checkout-complete\.html/);

    // ── Step 4: Verify confirmation messages ─────────────────
    const header  = await confirmPage.getHeaderText();
    const subText = await confirmPage.getSubText();

    expect(header.trim()).toBe(CONFIRMATION.header);
    expect(subText.trim()).toBe(CONFIRMATION.subText);

    // ── Step 5: Go back home; cart badge must be gone ────────
    await confirmPage.goBackHome();
    await expect(page).toHaveURL(/.*inventory\.html/);

    // The badge element must not be visible (cart is empty)
    await expect(productsPage.cartBadge).not.toBeVisible();
  });

  // ──────────────────────────────────────────────────────────────
  // TC13-TC15 – Parameterized checkout form validation
  // test.each runs this test once for each row in the array.
  // Each run has its own title (shown in the report).
  // ──────────────────────────────────────────────────────────────
  for (const tc of CHECKOUT_VALIDATION_CASES) {
    test(`TC13-15 - Checkout validation: ${tc.label}`, async ({ page }) => {
      await setupCheckout(page, ['backpack']);

      const checkoutPage = new CheckoutPage(page);

      // Fill the form with the test-data row (some fields are empty)
      await checkoutPage.fillForm(tc.firstName, tc.lastName, tc.postalCode);

      // Must stay on the same page (no redirect)
      await expect(page).toHaveURL(/.*checkout-step-one\.html/);

      // The exact error message must appear
      const msg = await checkoutPage.getErrorMessage();
      expect(msg.trim()).toBe(tc.expectedMsg);
    });
  }

  // ──────────────────────────────────────────────────────────────
  // TC16 – Cancel from overview returns to inventory
  // ──────────────────────────────────────────────────────────────
  test('TC16 - Cancel on overview page returns to products page', async ({ page }) => {
    await setupCheckout(page, ['backpack']);

    const checkoutPage  = new CheckoutPage(page);
    const overviewPage  = new CheckoutOverviewPage(page);

    await checkoutPage.completeCheckout(CHECKOUT.valid);
    await expect(page).toHaveURL(/.*checkout-step-two\.html/);

    await overviewPage.cancel();

    // Cancel on overview sends user back to inventory
    await expect(page).toHaveURL(/.*inventory\.html/);
  });

  // ──────────────────────────────────────────────────────────────
  // TC17 – Cancel on step-one returns to cart
  // ──────────────────────────────────────────────────────────────
  test('TC17 - Cancel on checkout step one returns to cart', async ({ page }) => {
    await setupCheckout(page, ['backpack']);

    const checkoutPage = new CheckoutPage(page);
    await checkoutPage.cancel();

    await expect(page).toHaveURL(/.*cart\.html/);
  });

});
