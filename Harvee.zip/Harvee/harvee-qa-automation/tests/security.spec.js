// tests/security.spec.js
// ------------------------------------------------------------------
// Security / authorization tests – covers TC22 and TC23.
//
// Verifies that unauthenticated users cannot access protected pages
// and are shown the correct error message (observed live in Phase 2).
// ------------------------------------------------------------------

const { test, expect } = require('@playwright/test');
const { LoginPage }    = require('../pages/LoginPage');
const { USERS, ERROR_MESSAGES } = require('../test-data/testData');

test.describe('Security - Protected Routes', () => {

  // ──────────────────────────────────────────────────────────────
  // TC22 – Unauthenticated access to /inventory.html
  //
  // Expected behavior (observed in Phase 2):
  //   The app redirects to "/" and shows the login error message
  //   "Epic sadface: You can only access '/inventory.html' when
  //    you are logged in."
  // ──────────────────────────────────────────────────────────────
  test('TC22 - Unauthenticated access to /inventory.html shows login required message', async ({ page }) => {
    // Navigate directly without logging in
    await page.goto('/inventory.html');

    // The app must redirect back to the login page
    await expect(page).toHaveURL('/');

    // The login page must show the protected-route error message
    const loginPage = new LoginPage(page);
    const message   = await loginPage.getErrorMessage();
    expect(message.trim()).toBe(ERROR_MESSAGES.protectedPage);
  });

  // ──────────────────────────────────────────────────────────────
  // TC23 – Unauthenticated access to /checkout-step-one.html
  //
  // The app should redirect and show a similar protection message.
  // ──────────────────────────────────────────────────────────────
  test('TC23 - Unauthenticated access to /checkout-step-one.html redirects to login', async ({ page }) => {
    await page.goto('/checkout-step-one.html');

    // Must land back at the login page
    await expect(page).toHaveURL('/');

    // Error message must be present (any non-empty message is acceptable;
    // the exact text for this route may differ slightly, so we check it
    // contains the key phrase)
    const loginPage = new LoginPage(page);
    const message   = await loginPage.getErrorMessage();
    expect(message.trim()).toContain("You can only access");
  });

  // ──────────────────────────────────────────────────────────────
  // TC22b – Login, Logout, then navigate to /inventory.html
  //         verifies session is cleared after logout
  // ──────────────────────────────────────────────────────────────
  test('TC22b - After logout, navigating to /inventory.html redirects to login', async ({ page }) => {
    // Login first
    const loginPage = new LoginPage(page);
    await loginPage.goto();
    await loginPage.login(USERS.standard.username, USERS.standard.password);
    await expect(page).toHaveURL(/.*inventory\.html/);

    // Logout via the side-nav menu
    await page.locator('#react-burger-menu-btn').click();
    await page.getByTestId('logout-sidebar-link').click();
    await expect(page).toHaveURL('/');

    // Now try to directly access the protected page
    await page.goto('/inventory.html');
    await expect(page).toHaveURL('/');

    const message = await loginPage.getErrorMessage();
    expect(message.trim()).toBe(ERROR_MESSAGES.protectedPage);
  });

});
