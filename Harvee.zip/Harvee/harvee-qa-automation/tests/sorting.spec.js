// tests/sorting.spec.js
// ------------------------------------------------------------------
// Sorting test suite – covers TC05, TC06, TC07, TC20.
//
// Sort tests collect the ENTIRE price list (or name list) displayed
// on the page, then compare it against a sorted copy made in JS.
// This verifies every product is in the right place, not just the
// first or last item.
// ------------------------------------------------------------------

const { test, expect } = require('@playwright/test');
const { LoginPage }    = require('../pages/LoginPage');
const { ProductsPage } = require('../pages/ProductsPage');
const { USERS, SORT_OPTIONS } = require('../test-data/testData');

test.describe('Product Sorting', () => {

  // Shared login helper – each test calls this to set up its own state.
  async function loginAsStandardUser(page) {
    const loginPage = new LoginPage(page);
    await loginPage.goto();
    await loginPage.login(USERS.standard.username, USERS.standard.password);
    await expect(page).toHaveURL(/.*inventory\.html/);
  }

  // ──────────────────────────────────────────────────────────────
  // TC05 – Sort price low to high
  // ──────────────────────────────────────────────────────────────
  test('TC05 - Sort price low to high: entire price list and names match expected order', async ({ page }) => {
    await loginAsStandardUser(page);
    const productsPage = new ProductsPage(page);

    // Choose the sort option
    await productsPage.sortProducts(SORT_OPTIONS.priceLH);

    // Collect BOTH names and prices after sorting
    const displayedNames  = await productsPage.getAllProductNames();
    const displayedPrices = await productsPage.getAllProductPrices();

    // Build sorted copies independently in JS
    // We sort prices ascending; names should follow the same re-ordering.
    // Strategy: zip names+prices into pairs, sort by price, then unzip.
    const pairs = displayedNames.map((name, i) => ({
      name,
      price: displayedPrices[i],
    }));

    // What we expect the app to show (low → high)
    const sortedPairs = [...pairs].sort((a, b) => a.price - b.price);
    const expectedPrices = sortedPairs.map((p) => p.price);
    const expectedNames  = sortedPairs.map((p) => p.name);

    // The displayed order must equal the sorted order exactly
    expect(displayedPrices).toEqual(expectedPrices);
    expect(displayedNames).toEqual(expectedNames);
  });

  // ──────────────────────────────────────────────────────────────
  // TC06 – Sort price high to low
  // ──────────────────────────────────────────────────────────────
  test('TC06 - Sort price high to low: entire price list and names match expected order', async ({ page }) => {
    await loginAsStandardUser(page);
    const productsPage = new ProductsPage(page);

    await productsPage.sortProducts(SORT_OPTIONS.priceHL);

    const displayedNames  = await productsPage.getAllProductNames();
    const displayedPrices = await productsPage.getAllProductPrices();

    const pairs = displayedNames.map((name, i) => ({
      name,
      price: displayedPrices[i],
    }));
    const sortedPairs = [...pairs].sort((a, b) => b.price - a.price);

    expect(displayedPrices).toEqual(sortedPairs.map((p) => p.price));
    expect(displayedNames).toEqual(sortedPairs.map((p) => p.name));
  });

  // ──────────────────────────────────────────────────────────────
  // TC07 – Default sort is Name A-Z
  // ──────────────────────────────────────────────────────────────
  test('TC07 - Default sort is Name A to Z', async ({ page }) => {
    await loginAsStandardUser(page);
    const productsPage = new ProductsPage(page);

    // No explicit sort change – read the current state
    const displayedNames = await productsPage.getAllProductNames();

    // Build a sorted-alphabetically copy
    const sortedNames = [...displayedNames].sort((a, b) =>
      a.localeCompare(b)
    );

    expect(displayedNames).toEqual(sortedNames);
  });

  // ──────────────────────────────────────────────────────────────
  // TC20 – Sort Name Z to A
  // ──────────────────────────────────────────────────────────────
  test('TC20 - Sort name Z to A: entire name list matches expected order', async ({ page }) => {
    await loginAsStandardUser(page);
    const productsPage = new ProductsPage(page);

    await productsPage.sortProducts(SORT_OPTIONS.nameZA);

    const displayedNames = await productsPage.getAllProductNames();
    const sortedNames = [...displayedNames].sort((a, b) =>
      b.localeCompare(a)
    );

    expect(displayedNames).toEqual(sortedNames);
  });

});
