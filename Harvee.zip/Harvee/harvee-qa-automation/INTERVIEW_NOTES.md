# INTERVIEW_NOTES.md
# Harvee Technologies QA Assessment – Interview Preparation

---

## C1 – Checkout Incident Investigation (7-Step Process)

*This is designed to be spoken aloud in an interview. Practise saying each step out loud.*

---

**Situation:** The automated checkout test is failing in the CI pipeline. Customers may be experiencing checkout issues in production. Here is how I would investigate.

---

**Step 1 – Confirm the Failure**

> "First, I confirm exactly what is failing. I look at the CI pipeline report to see which test failed, what the error message says, and whether there is a screenshot or trace file attached. I want to know: did the test throw an assertion error, a timeout, or a navigation error? This tells me where to focus."

- Open the HTML report: `npx playwright show-report`
- Look at the failure screenshot in `test-results/artifacts/`
- Read the full error stack trace in the console or JUnit XML

---

**Step 2 – Check If It Is Flaky or Consistent**

> "I ask: is this test always failing, or did it fail once? I re-run the test three times. If it fails consistently, there is either a code change or an environment change. If it fails sometimes, it is flaky – likely a timing issue."

- Run: `npx playwright test tests/checkout.spec.js --headed` to watch it live
- Check the CI history: did it pass in the last 10 runs?

---

**Step 3 – Isolate the Failing Step**

> "I look at the error line number and match it to the test code. For example, if `overviewPage.getTotal()` times out, I know the overview page either did not load, or the total label's selector changed. I open the app manually and try the same flow to see if it is a real bug or a selector problem."

- Manually log in and perform the checkout flow in a browser
- Compare the actual DOM selector with what is in `CheckoutOverviewPage.js`

---

**Step 4 – Check Recent Changes**

> "I look at the git log to see what changed since the test last passed. If a developer changed a CSS class name or a data-test attribute, my locator is now stale. If no code changed, the problem might be the test environment, a network issue, or a data-state problem."

- Run: `git log --oneline -20` to see recent commits
- Check if any page object files or selectors were changed

---

**Step 5 – Reproduce Locally with Trace**

> "I run the failing test with trace enabled so I get a full Playwright trace file. I then open it with `npx playwright show-trace trace.zip` to see a step-by-step replay of exactly what the browser did, including the DOM state at each click."

- Run: `npx playwright test tests/checkout.spec.js --trace on`
- Open the trace viewer to see the exact failure point

---

**Step 6 – Fix and Verify**

> "Once I find the root cause, I fix it. If it is a selector, I update the page object. If it is a timing issue, I add a proper web-first assertion instead of a sleep. Then I run the full suite three times to confirm there is no regression and the fix is stable."

- Update `pages/CheckoutOverviewPage.js` if selector changed
- Run full suite: `npx playwright test` (×3)

---

**Step 7 – Document and Prevent**

> "After fixing, I update the `AI_USAGE.md` or a 'lessons learned' note so the team knows what happened. I also look at whether other tests use the same fragile pattern and fix those proactively. Finally, I make sure the CI pipeline now includes the trace artifact so future failures are easier to diagnose."

---

## C2 – Real Incident Write-Up

> **⚠️ IMPORTANT:** No real production incident was provided for this submission. The template below uses a **HYPOTHETICAL** scenario as a learning structure. You must replace this with your own genuine experience. Never use a hypothetical scenario in an interview and present it as real.
>
> **How to adapt this to your real experience:**
> 1. Replace the hypothetical scenario with something you actually observed or worked on.
> 2. Keep the same 7-heading structure – interviewers value structure.
> 3. Be honest about your role: "I found the bug" vs "I was told about it" vs "I helped investigate".
> 4. If you have no production incidents, use a "significant test failure you found during testing" instead.

---

### HYPOTHETICAL Incident: Checkout Total Displaying Wrong Amount

*(This is a fabricated scenario for structural guidance only.)*

---

**Detection**

The automated TC12 checkout test began failing in CI with the assertion:
```
Expected: 39.98
Received: 39.97
```
The difference of $0.01 in the total matched a floating-point rounding issue. The test was passing locally because the local Node version handled the rounding differently from the CI server.

---

**Impact**

- No real user was affected (this was caught pre-release in CI).
- If released, customers on items totalling certain prices might see a 1-cent discrepancy between the displayed total and their payment charge.

---

**Root Cause**

The checkout overview page computed tax as `subtotal * 0.08` using JavaScript floating-point arithmetic. `29.99 * 0.08 = 2.3992000000000002` (not `2.40`). The displayed total was rounded to 2 decimals visually, but the underlying number differed by a fraction, which caused the assertion `expect(total).toBe(subtotal + tax)` to fail.

---

**Client Communication**

An internal Slack message was sent to the team:
> "CI checkout test is failing due to floating-point precision in tax calculation. This is a pre-release catch. No user impact. Investigating fix now. ETA: 30 minutes."

---

**Corrective Action**

- Updated `CheckoutOverviewPage.getTotal()` to round values to 2 decimal places before returning.
- Switched assertion from `toBe()` to `toBeCloseTo(value, 2)` to handle inherent floating-point imprecision.

---

**Prevention**

- Added a comment in the test explaining WHY `toBeCloseTo` is used instead of exact equality.
- Added a note in `INTERVIEW_NOTES.md` so future contributors understand the pattern.

---

**Lessons Learned**

1. Never use `toBe()` for floating-point currency comparisons. Always use `toBeCloseTo(x, 2)`.
2. Run CI on the same Node.js version as local development to catch environment-specific rounding differences early.
3. The 15-minute pre-investigation (checking CI logs and reading the exact error) saved hours of misdirected debugging.

---

*End of C2. Replace with your real experience before submitting.*
